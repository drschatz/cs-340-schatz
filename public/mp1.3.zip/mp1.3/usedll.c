#include <stdio.h>
#include <string.h>
#include "dll.h"
#include <stdlib.h>


void test_char_list() {    
    dllListc cl;
    dllInitc(&cl);
    if(cl.head != 0 || cl.tail !=0){
        printf("dllInitc: failed\n");
    }
    else{
        printf("dllInitc: success\n");
    }
    
    dllPushc(&cl, 'A');
    dllPushc(&cl, 'B');
    dllPushc(&cl, 'C');
    // C - B - A
     if(cl.head->data != 'C' || cl.tail->data != 'A' || 
        cl.head->next->data != 'B' || cl.tail->prev->data != 'B' ||
        cl.head->prev != 0 || cl.tail->next != 0){
        printf("dllPushc: failed\n");
    }
    else{
        printf("dllPushc: success\n");
    }
    dllEnqueuec(&cl, 'X');
    dllEnqueuec(&cl, 'Y');
    dllEnqueuec(&cl, 'Z');
    // C - B - A - X - Y - Z
    if(cl.head->data != 'C' || cl.tail->data != 'Z' || 
        cl.head->next->data != 'B' || cl.tail->prev->data != 'Y' ||
        cl.head->next->next->data != 'A' || cl.tail->prev->prev->next->data != 'Y' ||
        cl.head->prev != 0 || cl.tail->next != 0){
        printf("dllEnqueuec: failed\n");
    }
    else{
        printf("dllEnqueuec: success\n");
    }
    dllNodec *found = dllFindc(&cl, 'A');
    if(found->data != 'A' || found->next->data != 'X'){
        printf("dllFindc test 1: failed\n");
    }
    printf("dllFindc test 1: success\n");
    
    found = dllFindc(&cl, 'M');
    if(found != 0){
        printf("dllFindc test 2: failed\n");
    }
    printf("dllFindc test 2: success\n");
    
    char c = dllPopc(&cl, '?');
    // B - A - X - Y - Z
    if(c != 'C' || cl.head->data != 'B' || cl.tail->data != 'Z' || 
        cl.head->next->data != 'A' || cl.tail->prev->data != 'Y' ||
        cl.head->prev != 0 || cl.tail->next != 0){
        printf("dllPopc: failed\n");
    }
    else{
        printf("dllPopc: success\n");
    }
    char c_2 = dllShiftc(&cl, '?');
    // B - A - X - Y
    if(c_2 != 'Z' || cl.head->data != 'B' || cl.tail->data != 'Y' || 
        cl.head->next->data != 'A' || cl.tail->prev->data != 'X' ||
        cl.head->prev != 0 || cl.tail->next != 0){
        printf("dllShiftc: failed\n");
    }
    else{
        printf("dllShiftc: success\n");
    }
    dllClearc(&cl);
     if(cl.head != 0 || cl.tail !=0){
        printf("dllClearc: failed\n");
    }
    else{
        printf("dllClearc: success\n");
    }
    
    c = dllPopc(&cl, '?');
    c_2 = dllShiftc(&cl, '?');
    if(c != '?' || c_2 != '?'){
        printf("Empty popc and shiftc: failed\n");
    }
    printf("Empty popc and shiftc: success\n");
}
void test_string_list() {    
    dllLists cl;
    dllInits(&cl);
    if(cl.head != 0 || cl.tail !=0){
        printf("dllInits: failed\n");
    }
    else{
        printf("dllInits: success\n");
    }
    
    dllPushs(&cl, "apple");
    dllPushs(&cl, "banana");
    dllPushs(&cl, "cherry");
    // C - B - A
     if(strcmp(cl.head->data, "cherry") != 0 || strcmp(cl.tail->data, "apple") != 0 || 
        strcmp(cl.head->next->data, "banana") != 0 || strcmp(cl.tail->prev->data, "banana") != 0 ||
        cl.head->prev != 0 || cl.tail->next != 0){
        printf("dllPushs: failed\n");
    }
    else{
        printf("dllPushs: success\n");
    }
    dllEnqueues(&cl, "Xi");
    dllEnqueues(&cl, "Yi");
    dllEnqueues(&cl, "Zi");
    // C - B - A - X - Y - Z
    if(strcmp(cl.head->data, "cherry") != 0 || strcmp(cl.tail->data, "Zi") != 0 || 
        strcmp(cl.head->next->data, "banana") != 0 || strcmp(cl.tail->prev->data, "Yi") != 0 ||
        strcmp(cl.head->next->next->data, "apple") != 0 || strcmp(cl.tail->prev->prev->next->data, "Yi") != 0 ||
        cl.head->prev != 0 || cl.tail->next != 0){
        printf("dllEnqueues: failed\n");
    }
    else{
        printf("dllEnqueues: success\n");
    }
    char tmp_a[6] = "apple";
    dllNodes *found = dllFinds(&cl, tmp_a);
    if(strcmp(found->data, "apple") != 0 || strcmp(found->next->data, "Xi") != 0){
        printf("dllFinds test 1: failed\n");
    }
    printf("dllFinds test 1: success\n");
    
    char tmp_m[7] = "mapple";
    found = dllFinds(&cl, tmp_m);
    if(found != 0){
        printf("dllFinds test 2: failed\n");
    }
    printf("dllFinds test 2: success\n");
    
    char empty_c[2] = "?";
    char* c = dllPops(&cl, empty_c);
    // B - A - X - Y - Z
    if(strcmp(c, "cherry") != 0 || strcmp(cl.head->data, "banana") != 0 || strcmp(cl.tail->data, "Zi") != 0 || 
        strcmp(cl.head->next->data, "apple") != 0 || strcmp(cl.tail->prev->data, "Yi") != 0 ||
        cl.head->prev != 0 || cl.tail->next != 0){
        printf("dllPops: failed\n");
    }
    else{
        printf("dllPops: success\n");
    }
    char* c_2 = dllShifts(&cl, empty_c);
    // B - A - X - Y
    if(strcmp(c_2, "Zi") != 0 || strcmp(cl.head->data, "banana") != 0 || strcmp(cl.tail->data, "Yi") != 0 || 
        strcmp(cl.head->next->data, "apple") != 0 || strcmp(cl.tail->prev->data, "Xi") != 0 ||
        cl.head->prev != 0 || cl.tail->next != 0){
        printf("dllShifts: failed\n");
    }
    else{
        printf("dllShifts: success\n");
    }
    dllClears(&cl);
     if(cl.head != 0 || cl.tail !=0){
        printf("dllClears: failed\n");
    }
    else{
        printf("dllClears: success\n");
    }
    
    c = dllPops(&cl, empty_c);
    c_2 = dllShifts(&cl, empty_c);
    if(strcmp(c, empty_c) != 0 || strcmp(c_2, empty_c) != 0 ){
        printf("Empty pops and shifts: failed\n");
    }
    printf("Empty pops and shifts: success\n");
}
int main(int argc, char *argv[]) {
    test_char_list();
    test_string_list();
    return 0;
}