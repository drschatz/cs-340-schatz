#!/usr/bin/env python3
"""
Test runner. Not given to students (the autograder uses --format json).

Usage:
    python3 run_tests.py --tests path/to/tests.py CORRECT [BUG ...]
                         [--also-correct VARIANT ...]
                         [--format text|json] [--output out.json]

Imports every function named test_* from the tests file and runs each one
against each scheduler executable.

Roles
  The FIRST scheduler listed is the correct one. Every --also-correct
  scheduler is a different but equally valid implementation (for example one
  that reports times slightly differently, within the 0.3s tolerance). All
  of these "reference" schedulers must pass every test. Every other scheduler
  is a buggy variant that the tests are supposed to catch.

Anonymizing (on by default, disable with --no-anonymize)
  Before running, every scheduler is copied into a fresh temp folder under a
  shuffled neutral name (sched_07, sched_12, ...). Tests only ever see those
  paths, so they cannot tell the correct scheduler from a buggy one by its
  name or location. Results are reported under the paths you gave.

Output
  --format text  (DEFAULT) readable output for people. One scheduler gives a
                 simple list; several give a grid of tests by scheduler,
                 ending with "Bugs caught: N of M".
  --format json  prints ONE JSON object to stdout. Use this in the autograder.
  --output FILE  always writes the JSON to FILE, whichever format is printed.

The JSON looks like:

{
  "collected": 2,                           # number of test_* functions found
  "tests": ["test_a", "test_b"],            # collected test names, sorted
  "references_all_passed": true,            # every reference scheduler passed every test
  "schedulers": {
    "<path as given>": {
      "role": "reference",                  # "reference" (must pass) or "bug" (should fail)
      "results": {"test_a": "PASS", "test_b": "FAIL"},   # PASS | FAIL | ERROR | TIMEOUT
      "messages": {"test_b": "assert x == y  (tests.py line 12)"},
      "passed": 1,
      "failed": 1,                          # FAIL + ERROR + TIMEOUT
      "total": 2,
      "all_passed": false,
      "any_failed": true                    # for a "bug": true => the tests caught it
    }
  }
}

A student's score is the number of "bug" entries with any_failed true, but
only if references_all_passed is true.

Result meanings:
  PASS     test function returned normally
  FAIL     an assertion failed (AssertionError)
  ERROR    any other exception, including the scheduler crashing or the
           harness failing to find or parse its output
  TIMEOUT  the test took longer than --test-timeout seconds

A failure message names the test file line that failed and shows its source,
for example "assert get_by_id(r, 1).start_time_s < 1  (tests.py line 12)".
If the assert has its own message, that message is shown first.

If no test_* functions are found, the output has "collected": 0 and an
"error" message (JSON) or an "ERROR:" line (text), and the exit code is 3.
Show the student that message instead of grading, since "no tests" would
otherwise look like a clean run.

Exit code is 0 whenever tests ran, even if some failed. It is 3 for the
no-tests case above. It is 2 (and nothing is printed to stdout) if the runner
itself cannot work, for example the tests file cannot be imported.
"""
import argparse
import importlib.util
import json
import os
import random
import shutil
import signal
import sys
import tempfile
import traceback

TESTS_FILE = ""     # absolute path of the tests file, set by load_tests


class TestTimeout(BaseException):
    pass


def _on_alarm(signum, frame):
    raise TestTimeout()


def load_tests(path):
    global TESTS_FILE
    path = os.path.abspath(path)
    TESTS_FILE = path
    sys.path.insert(0, os.path.dirname(path))   # so the harness import works
    spec = importlib.util.spec_from_file_location("student_tests", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    tests = []
    for name in dir(module):
        if name.startswith("test_") and callable(getattr(module, name)):
            tests.append((name, getattr(module, name)))
    return sorted(tests)


def first_line(exc):
    text = str(exc).strip()
    line = text.split("\n")[0] if text else ""
    label = type(exc).__name__
    return (f"{label}: {line}" if line else label)[:300]


def describe(exc):
    """Short, useful failure text: the message plus the test line that failed."""
    text = str(exc).strip()
    msg = text.split("\n")[0] if text else ""
    frames = traceback.extract_tb(exc.__traceback__)
    ours = [f for f in frames if os.path.abspath(f.filename) == TESTS_FILE]
    where = ""
    src = ""
    if ours:
        f = ours[-1]
        where = f"{os.path.basename(f.filename)} line {f.lineno}"
        src = (f.line or "").strip()

    if isinstance(exc, AssertionError):
        head = msg or src or "assertion failed"
        if msg and src and src != msg:
            head = f"{msg}  [{src}]"
    else:
        head = f"{type(exc).__name__}: {msg}" if msg else type(exc).__name__
        if src:
            head = f"{head}  [{src}]"
    out = f"{head}  ({where})" if where else head
    return out[:300]


def run_one(fn, sched_path, timeout_s):
    signal.signal(signal.SIGALRM, _on_alarm)
    signal.setitimer(signal.ITIMER_REAL, timeout_s)
    try:
        fn(sched_path)
        return "PASS", ""
    except TestTimeout:
        return "TIMEOUT", f"exceeded {timeout_s}s"
    except AssertionError as e:
        return "FAIL", describe(e)
    except BaseException as e:      # includes SystemExit from student code
        return "ERROR", describe(e)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)


def make_anonymous_copies(paths):
    """Copy each scheduler to a temp folder under a shuffled neutral name."""
    tmp = tempfile.mkdtemp(prefix="grader_")
    ids = list(range(len(paths)))
    random.SystemRandom().shuffle(ids)
    mapping = {}
    for p, i in zip(paths, ids):
        dest = os.path.join(tmp, f"sched_{i:02d}")
        try:
            shutil.copy2(p, dest)
            mapping[p] = dest
        except OSError:
            mapping[p] = os.path.abspath(p)   # let the tests report the problem
    return tmp, mapping


def render_single(report, sched):
    v = report["schedulers"][sched]
    lines = [f"Scheduler: {sched}", ""]
    for n in report["tests"]:
        lines.append(f"  {v['results'][n]:<7} {n}")
        if n in v["messages"]:
            lines.append(f"          {v['messages'][n]}")
    lines.append("")
    if v["all_passed"]:
        lines.append(f"All {v['total']} tests passed.")
    else:
        lines.append(f"{v['failed']} of {v['total']} tests failed.")
    return "\n".join(lines)


def render_grid(report):
    """One row per test, one column per scheduler."""
    scheds = list(report["schedulers"])
    labels = [os.path.basename(s) or s for s in scheds]
    if len(set(labels)) != len(labels):          # same filename in different folders
        labels = scheds
    names = report["tests"]
    name_w = max([len("Test")] + [len(n) for n in names])
    col_w = [max(len(l), len("TIMEOUT"), len("passed")) for l in labels]

    def row(first, cells):
        return first.ljust(name_w) + "".join("  " + c.ljust(w) for c, w in zip(cells, col_w))

    lines = [row("Test", labels)]
    lines.append("-" * len(lines[0]))
    for n in names:
        lines.append(row(n, [report["schedulers"][s]["results"][n] for s in scheds]))
    lines.append("-" * len(lines[0]))
    lines.append(row("passed", [f"{report['schedulers'][s]['passed']}/{report['schedulers'][s]['total']}"
                                for s in scheds]))
    lines.append("")
    for s, label in zip(scheds, labels):
        v = report["schedulers"][s]
        if v["all_passed"]:
            lines.append(f"{label}: all {v['total']} tests passed")
        else:
            lines.append(f"{label}: {v['failed']} of {v['total']} tests failed")
    details = [(l, t, report["schedulers"][s]["messages"][t])
               for s, l in zip(scheds, labels)
               for t in names if t in report["schedulers"][s]["messages"]]
    if details:
        lines += ["", "Failure details:"]
        for l, t, m in details:
            lines.append(f"  [{l}] {t}")
            lines.append(f"      {m}")

    refs = [(s, l) for s, l in zip(scheds, labels) if report["schedulers"][s]["role"] == "reference"]
    bugs = [(s, l) for s, l in zip(scheds, labels) if report["schedulers"][s]["role"] == "bug"]
    bad_refs = [l for s, l in refs if not report["schedulers"][s]["all_passed"]]
    if bugs or bad_refs:
        lines += ["", "=" * 40]
        if bad_refs:
            lines.append("WARNING: tests fail on the correct scheduler(s): " + ", ".join(bad_refs))
            lines.append("Every test must pass on those. Fix them first; bugs caught do not count until then.")
        if bugs:
            caught = [l for s, l in bugs if report["schedulers"][s]["any_failed"]]
            missed = [l for s, l in bugs if not report["schedulers"][s]["any_failed"]]
            lines.append(f"Bugs caught: {len(caught)} of {len(bugs)}")
            if missed:
                lines.append("Missed: " + ", ".join(missed))
        lines.append("=" * 40)
    return "\n".join(lines)


def render_text(report):
    if len(report["schedulers"]) == 1:
        return render_single(report, next(iter(report["schedulers"])))
    return render_grid(report)


def main():
    ap = argparse.ArgumentParser(description="Scheduler test runner")
    ap.add_argument("--format", choices=["text", "json"], default="text",
                    help="stdout format (default text; the autograder should use json)")
    ap.add_argument("--tests", default="tests.py", help="path to the tests file")
    ap.add_argument("--test-timeout", type=float, default=30.0,
                    help="seconds allowed per test per scheduler (default 30)")
    ap.add_argument("--output", help="also write the JSON to this file")
    ap.add_argument("--also-correct", action="append", default=[], metavar="SCHEDULER",
                    help="another valid implementation that must also pass every test "
                         "(repeat the flag for several)")
    ap.add_argument("--no-anonymize", action="store_true",
                    help="run the schedulers from their real paths instead of neutral copies")
    ap.add_argument("schedulers", nargs="+",
                    help="the correct scheduler first, then the buggy ones")
    args = ap.parse_args()

    try:
        tests = load_tests(args.tests)
    except BaseException as e:
        print(f"run_tests: could not load {args.tests}: {first_line(e)}", file=sys.stderr)
        return 2

    report = {"collected": len(tests), "tests": [name for name, _ in tests],
              "references_all_passed": False, "schedulers": {}}

    def emit():
        text = json.dumps(report, indent=2)
        if args.output:
            with open(args.output, "w", encoding="utf-8") as f:
                f.write(text + "\n")
        return text

    if not tests:
        report["error"] = ("No test functions found. Test functions must be named "
                           "test_<something> and take one argument, the scheduler path.")
        text = emit()
        print("ERROR: " + report["error"] if args.format == "text" else text)
        return 3

    references = [args.schedulers[0]] + args.also_correct
    bug_list = args.schedulers[1:]
    ordered = [(s, "reference") for s in references] + [(s, "bug") for s in bug_list]

    tmp, mapping = (None, {})
    if not args.no_anonymize:
        tmp, mapping = make_anonymous_copies([s for s, _ in ordered])

    try:
        for sched, role in ordered:
            run_path = mapping.get(sched, os.path.abspath(sched))
            results, messages = {}, {}
            for name, fn in tests:
                status, msg = run_one(fn, run_path, args.test_timeout)
                results[name] = status
                if msg:
                    messages[name] = msg
            failed = sum(1 for s in results.values() if s != "PASS")
            report["schedulers"][sched] = {
                "role": role,
                "results": results,
                "messages": messages,
                "passed": len(results) - failed,
                "failed": failed,
                "total": len(results),
                "all_passed": failed == 0,
                "any_failed": failed > 0,
            }
    finally:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)

    report["references_all_passed"] = all(
        v["all_passed"] for v in report["schedulers"].values() if v["role"] == "reference")

    text = emit()
    print(render_text(report) if args.format == "text" else text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
