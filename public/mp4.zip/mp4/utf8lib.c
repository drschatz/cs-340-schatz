#include "utf8lib.h" // access to the function and struct declarations for this MP
#include <stdlib.h>  // access to malloc/free
#include <string.h>  // access to strcmp/strlen

struct _replacement_set_t {
  // TO DO: define what goes inside this struct
};

