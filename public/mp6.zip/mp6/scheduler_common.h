/*
 * scheduler_common.h
 * Shared types, parsing, and utilities for all scheduler implementations.
 *
 * Command line:   scheduler <jobs_file> [--cpu-capacity N] [--summary PATH]
 *
 * Jobs file (one job per line, blank lines and '#' comments ignored):
 *
 *     [unique_ID=<int>] [cpu=<int>] [priority=<int>] [arrival_time=<float>] <command...>
 *
 * Defaults: unique_ID = line order (0,1,2,...), cpu=1, priority=0,
 * arrival_time=0. A HIGHER priority number means MORE important.
 * Arrival times are seconds after the scheduler starts.
 */

#ifndef SCHEDULER_COMMON_H
#define SCHEDULER_COMMON_H

#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <time.h>
#include <errno.h>
#include <signal.h>
#include <ctype.h>

#define MAX_JOBS        1024
#define MAX_CMD         4096
#define MAX_PATH        1024
#define MAX_ARGS        256
#define TICK_NS         100000000L   /* scheduler wakes every 0.1s */
#define STATUS_SUCCESS  "SUCCESS"
#define STATUS_UNSCHED  "UNSCHEDULABLE"

typedef struct {
    int    job_id;
    char   cmd[MAX_CMD];
    int    cpu;
    int    priority;        /* higher number = more important */
    double arrival_s;       /* seconds after scheduler start */
} Job;

typedef struct {
    int    job_id;
    char   cmd[MAX_CMD];
    int    cpu;
    int    priority;
    char   status[32];
    double arrival_s;
    double start_s;         /* < 0 means null (UNSCHEDULABLE) */
    double end_s;           /* < 0 means null (UNSCHEDULABLE) */
} Result;

typedef struct {
    int    cpu_capacity;
    char   summary_path[MAX_PATH];
} Config;

static inline double now_s(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

static void safe_mkdir(const char *path) {
    char tmp[MAX_PATH];
    snprintf(tmp, sizeof(tmp), "%s", path);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            mkdir(tmp, 0755);
            *p = '/';
        }
    }
    mkdir(tmp, 0755);
}

static void json_escape(const char *src, char *dst, size_t dstsz) {
    size_t j = 0;
    for (size_t i = 0; src[i] && j + 7 < dstsz; i++) {
        unsigned char c = (unsigned char)src[i];
        if (c == '"' || c == '\\') { dst[j++] = '\\'; dst[j++] = (char)c; }
        else if (c == '\n') { dst[j++] = '\\'; dst[j++] = 'n'; }
        else if (c == '\t') { dst[j++] = '\\'; dst[j++] = 't'; }
        else if (c < 0x20)  { j += (size_t)snprintf(dst + j, dstsz - j, "\\u%04x", c); }
        else dst[j++] = (char)c;
    }
    dst[j] = '\0';
}

/* Write summary.json: a list with one object per job. */
static void write_summary(const Config *cfg, Result *results, int n) {
    char tmp[MAX_PATH];
    snprintf(tmp, sizeof(tmp), "%s", cfg->summary_path);
    char *slash = strrchr(tmp, '/');
    if (slash) { *slash = '\0'; safe_mkdir(tmp); }

    FILE *f = fopen(cfg->summary_path, "w");
    if (!f) { perror("fopen summary"); return; }

    fprintf(f, "[\n");
    for (int i = 0; i < n; i++) {
        Result *r = &results[i];
        static char cmd_e[MAX_CMD * 6];
        json_escape(r->cmd, cmd_e, sizeof(cmd_e));

        fprintf(f, "  {\n");
        fprintf(f, "    \"job_id\": %d,\n",          r->job_id);
        fprintf(f, "    \"cmd\": \"%s\",\n",         cmd_e);
        fprintf(f, "    \"cpu\": %d,\n",             r->cpu);
        fprintf(f, "    \"priority\": %d,\n",        r->priority);
        fprintf(f, "    \"status\": \"%s\",\n",      r->status);
        fprintf(f, "    \"arrival_time_s\": %.4f,\n", r->arrival_s);
        if (r->start_s < 0) fprintf(f, "    \"start_time_s\": null,\n");
        else                fprintf(f, "    \"start_time_s\": %.4f,\n", r->start_s);
        if (r->end_s < 0)   fprintf(f, "    \"end_time_s\": null\n");
        else                fprintf(f, "    \"end_time_s\": %.4f\n", r->end_s);
        fprintf(f, "  }%s\n", (i < n - 1) ? "," : "");
    }
    fprintf(f, "]\n");
    fclose(f);
}

/* Parse jobs file. Returns number of jobs read. */
static int parse_jobs(const char *path, Job *jobs, int max_jobs) {
    FILE *f = fopen(path, "r");
    if (!f) { perror("fopen jobs"); return 0; }

    static char line[MAX_CMD];
    int n = 0;

    while (fgets(line, sizeof(line), f) && n < max_jobs) {
        size_t len = strlen(line);
        while (len > 0 && isspace((unsigned char)line[len-1])) line[--len] = '\0';

        char *p = line;
        while (isspace((unsigned char)*p)) p++;
        if (*p == '\0' || *p == '#') continue;

        Job *job = &jobs[n];
        memset(job, 0, sizeof(*job));
        job->job_id    = n;
        job->cpu       = 1;
        job->priority  = 0;
        job->arrival_s = 0.0;

        while (1) {
            if (strncmp(p, "unique_ID=", 10) == 0)         job->job_id = atoi(p + 10);
            else if (strncmp(p, "cpu=", 4) == 0)           job->cpu = atoi(p + 4);
            else if (strncmp(p, "priority=", 9) == 0)      job->priority = atoi(p + 9);
            else if (strncmp(p, "arrival_time=", 13) == 0) job->arrival_s = atof(p + 13);
            else break;
            while (*p && !isspace((unsigned char)*p)) p++;
            while (isspace((unsigned char)*p)) p++;
        }

        if (*p == '\0') continue;  /* no command after prefixes */
        snprintf(job->cmd, sizeof(job->cmd), "%s", p);
        n++;
    }

    fclose(f);
    return n;
}

static const char* parse_args(int argc, char **argv, Config *cfg) {
    memset(cfg, 0, sizeof(*cfg));
    cfg->cpu_capacity = 4;
    snprintf(cfg->summary_path, sizeof(cfg->summary_path), "summary.json");

    if (argc < 2) {
        fprintf(stderr, "Usage: %s <jobs_file> [--cpu-capacity N] [--summary PATH]\n", argv[0]);
        exit(1);
    }
    for (int i = 2; i < argc; i++) {
        if (strcmp(argv[i], "--cpu-capacity") == 0 && i + 1 < argc)
            cfg->cpu_capacity = atoi(argv[++i]);
        else if (strcmp(argv[i], "--summary") == 0 && i + 1 < argc)
            snprintf(cfg->summary_path, sizeof(cfg->summary_path), "%s", argv[++i]);
    }
    return argv[1];
}

/*
 * Simulation helpers. Time is counted in whole ticks of 0.1s so results are
 * exact and deterministic.
 */
#define TICK_S 0.1

/* seconds -> ticks, rounding up (tolerant of float noise like 0.30000000004) */
static inline long secs_to_ticks(double s) {
    double x = s * 10.0;
    long t = (long)x;
    if (x - (double)t > 1e-6) t++;
    return t < 0 ? 0 : t;
}

/* Work a job needs, in ticks. Commands look like "workload N" (N seconds).
 * Anything else counts as zero work. */
static inline long job_work_ticks(const char *cmd) {
    if (strncmp(cmd, "workload", 8) != 0) return 0;
    const char *p = cmd + 8;
    while (isspace((unsigned char)*p)) p++;
    return secs_to_ticks(atof(p));
}

static int cmp_result_by_id(const void *a, const void *b) {
    return ((const Result*)a)->job_id - ((const Result*)b)->job_id;
}

#endif /* SCHEDULER_COMMON_H */
