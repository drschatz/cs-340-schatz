from subprocess import run
import re
from os.path import exists
from os import unlink, stat

usedfunc = re.compile(r"DeclRefExpr[^\n]*Function 0x[a-f0-9]+ '([^']*)'")

def check_for_tokens(filename, tokens, mode='allow'):
    """Use clang's AST to check what functions are being used
    mode='allow' gives a set of functions that may be used
    mode='ban' gives a set of functions that may not be used
    returns a list of violations (an empty list if there are none)"""
    res = run(['clang','-Xclang','-ast-dump',filename], capture_output=True)
    used = set(usedfunc.findall(res.stdout.decode('utf-8')))
    filters = [re.compile(_) for _ in tokens if re.search(r'[^*$\\\[\]()]', _)]
    tokens = [_ for _ in tokens if not re.search(r'[^*$\\]', _)]
    errors = []
    if mode == 'allow':
        for token in used:
            if token in tokens or any(f.search(token) for f in filters): continue
            errors.append(token)
    else:
        for token in used:
            if token in tokens or any(f.search(token) for f in filters): errors.append(token)
    return errors


def valgrind(command, points, msg, msg2=None, timeout=None):
    """Uses valgrind on one command-line invocation"""
    if exists('.leaks'): unlink('.leaks')
    res = run(f'valgrind --trace-children=yes --leak-check=full -q --log-file=.leaks {command}', shell=True, capture_output=True, timeout=timeout)
    if exists('.leaks') and stat('.leaks').st_size > 2:
        print('❌ valgrind',msg2 if msg2 else msg)
        unlink('.leaks')
        return 0
    else:
        print('✅ valgrind',msg)
        return points


score = 0

try:

    banned = check_for_tokens('dll.c',['^dll', '^str', '^mem', 'malloc', 'calloc', 'realloc', 'free'])
    if banned:
        print('❌ library function limitations violated by', ', '.join(banned))
        quit()
    else:
        print('✅ library function limitations')
        score += 1


    run(['make','--silent','clean'])
    run(['make','--silent','dll_c'])

    if not exists('dll_c'):
        print('❌ failed to build with make')
        quit()
    else:
        print('✅ built without warnings or errors')
        score += 1

    res = run('./dll_c', shell=True, capture_output=True, timeout=5)
    output = res.stdout.decode('utf-8')
    
    if 'COMPREHENSIVE DLL FUNCTION TEST SUITE' not in output:
        print('❌ program does not run comprehensive tests')
        quit()
    
    if 'dllInitc: Initialized empty char list' in output:
        print('✅ dllInitc tested')
        score += 1
    else:
        print('❌ dllInitc not tested')
    
    if 'dllInits: Initialized empty string list' in output:
        print('✅ dllInits tested')
        score += 1
    else:
        print('❌ dllInits not tested')
    
    if 'dllPushc: Pushed' in output:
        print('✅ dllPushc tested')
        score += 1
    else:
        print('❌ dllPushc not tested')
    
    if 'dllPushs: Pushed' in output:
        print('✅ dllPushs tested')
        score += 1
    else:
        print('❌ dllPushs not tested')
    
    if 'dllEnqueuec: Enqueued' in output:
        print('✅ dllEnqueuec tested')
        score += 1
    else:
        print('❌ dllEnqueuec not tested')
    
    if 'dllEnqueues: Enqueued' in output:
        print('✅ dllEnqueues tested')
        score += 1
    else:
        print('❌ dllEnqueues not tested')
    
    if "dllFindc: Finding 'A': FOUND" in output and "dllFindc: Finding 'Q'" in output:
        print('✅ dllFindc tested')
        score += 1
    else:
        print('❌ dllFindc not tested')
    
    if "dllFinds: Finding 'banana': FOUND" in output and "dllFinds: Finding 'orange'" in output:
        print('✅ dllFinds tested')
        score += 1
    else:
        print('❌ dllFinds not tested')
    
    if 'dllPopc: Popped' in output and 'dllPopc on empty' in output:
        print('✅ dllPopc tested')
        score += 1
    else:
        print('❌ dllPopc not tested')
    
    if 'dllPops: Popped' in output and 'dllPops on empty' in output:
        print('✅ dllPops tested')
        score += 1
    else:
        print('❌ dllPops not tested')
    
    if 'dllShiftc: Shifted' in output and 'dllShiftc on empty' in output:
        print('✅ dllShiftc tested')
        score += 1
    else:
        print('❌ dllShiftc not tested')
    
    if 'dllShifts: Shifted' in output and 'dllShifts on empty' in output:
        print('✅ dllShifts tested')
        score += 1
    else:
        print('❌ dllShifts not tested')
    
    if 'dllClearc: Cleared entire list' in output:
        print('✅ dllClearc tested')
        score += 1
    else:
        print('❌ dllClearc not tested')
    
    if 'dllClears: Cleared entire list' in output:
        print('✅ dllClears tested')
        score += 1
    else:
        print('❌ dllClears not tested')
    
    if 'dllDetachc: Detached middle node' in output:
        print('✅ dllDetachc tested')
        score += 1
    else:
        print('❌ dllDetachc not tested')
    
    if 'dllDetachs: Detached middle node' in output:
        print('✅ dllDetachs tested')
        score += 1
    else:
        print('❌ dllDetachs not tested')
    
    if 'Testing Edge Cases' in output and 'Single element' in output:
        print('✅ edge cases tested')
        score += 1
    else:
        print('❌ edge cases not tested')
    
    score += valgrind('./dll_c', 1, 'no memory leaks')
    
finally:
    print(f"\nSCORE: {score} / 20")




