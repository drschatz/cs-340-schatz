from aiohttp import web
from aiohttp.web import Request, Response, json_response

routes = web.RouteTableDef()


# ---------------------------------------------------------------------------
# Global state
#
# Everything the hub tells you in /newhub is shared by all users.
# Everything about the game world (where a user is, what they have unlocked)
# must be stored separately for each user.
# ---------------------------------------------------------------------------

hub_url = None        # base URL of the hub, given to /newhub
domain_id = None      # this domain's id, from the hub's /register reply
domain_secret = None  # this domain's secret, from the hub's /register reply

# Every item this domain owns. Send this whole list to the hub in /newhub.
#
# An item with no "hidden" field stays in this domain; you place it yourself.
# An item with "hidden": "open" is hidden in another domain, where anyone can pick it up.
# An item with "hidden": "locked" is hidden in another domain, behind a barrier there.
domain_items = [
    {"name": "paper", "description": "A piece of paper.", "verb": {"read": "It says hello."}},  # stays here
]

users = {}  # {user_id: that user's game state}


# ---------------------------------------------------------------------------
# Suggested helpers for talking to the hub.
# You do not have to use these, but most solutions want something like them.
# Send requests with the shared client, for example:
#
#     async with client.post(hub_url + '/transfer', json={...}) as resp:
#         data = await resp.json()
#
# where client is req.app.client. Do not create your own ClientSession.
# ---------------------------------------------------------------------------

async def transfer(client, user, item, to):
    """Ask the hub to move an item. `to` is "inventory" or one of your location names."""
    raise NotImplementedError("TO DO")

async def query(client, user, location):
    """Ask the hub which item ids are in a location: "inventory" or one of your location names."""
    raise NotImplementedError("TO DO")

async def hosted(client, user, hidden):
    """Ask the hub which items from other domains you host that are hidden "open" or "locked".
    Use this the first time a user arrives, to find out which items to place."""
    raise NotImplementedError("TO DO")

async def send_score(client, user, score):
    """Tell the hub this user's score in this domain; 1.0 means they finished it."""
    raise NotImplementedError("TO DO")


# ---------------------------------------------------------------------------
# Endpoints called by the hub
# ---------------------------------------------------------------------------

@routes.post('/newhub')
async def newhub(req: Request) -> Response:
    """Connects this domain to a hub server.

    1. the hub calls this endpoint; the request body is the hub's URL
    2. this domain calls the hub's /register with its url, name, description, and items
    3. the hub replies with this domain's id, secret, and item ids
    """

    raise Warning("Code not finished")


@routes.post('/arrive')
async def arrive(req: Request) -> Response:
    """Called by the hub each time a user enters or re-enters this domain.

    Request body: {"secret", "user", "from", "owned", "carried", "dropped", "prize"}
    Reply with status 200, or 403 if the secret is wrong.
    """
    raise Warning("Code not finished")


@routes.post('/depart')
async def depart(req: Request) -> Response:
    """Called by the hub each time a user leaves this domain.

    Request body: {"secret", "user"}
    Reply with status 200, or 403 if the secret is wrong.
    Until this user arrives again, /command must answer them with status 409.
    """

    raise Warning("Code not finished")


@routes.post('/dropped')
async def dropped(req: Request) -> Response:
    """Called by the hub each time a user drops an item in this domain.

    Request body: {"secret", "user", "item"}
    Reply with the name of the location the user is in, as plain text (not JSON),
    or 403 if the secret is wrong. The hub stores the item at that location.
    Do not call /transfer here; the hub moves the item itself.
    """
    raise Warning("Code not finished")


# ---------------------------------------------------------------------------
# Endpoint called by the web UI
# ---------------------------------------------------------------------------

@routes.post("/command")
async def command(req : Request) -> Response:
    """Called by the web UI each time a user in this domain types a command.

    Request body: {"user", "command"} where command is a list of words.
    Reply with plain text (not JSON) to show the user.
    Reply with status 409 if the user is not currently in this domain.
    """

    raise Warning("Code not finished")


# Do not modify code below this line

@web.middleware
async def allow_cors(req, handler):
    """Bypass cross-origin resource sharing protections,
    allowing anyone to send messages from anywhere.
    Generally unsafe, but for this class project it should be OK."""
    resp = await handler(req)
    resp.headers["Access-Control-Allow-Origin"] = "*"
    return resp

async def start_session(app):
    """To be run on startup of each event loop. Makes singleton ClientSession"""
    from aiohttp import ClientSession, ClientTimeout
    app.client = ClientSession(timeout=ClientTimeout(total=3))

async def end_session(app):
    """To be run on shutdown of each event loop. Closes the singleton ClientSession"""
    await app.client.close()


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', type=str, default="0.0.0.0")
    parser.add_argument('-p','--port', type=int, default=3400)
    args = parser.parse_args()

    import socket
    whoami = socket.getfqdn()
    if '.' not in whoami: whoami = 'localhost'
    whoami += ':'+str(args.port)
    whoami = 'http://' + whoami
    print("URL to type into web prompt:\n\t"+whoami)
    print()

    app = web.Application(middlewares=[allow_cors])
    app.on_startup.append(start_session)
    app.on_shutdown.append(end_session)
    app.add_routes(routes)
    web.run_app(app, host=args.host, port=args.port)
