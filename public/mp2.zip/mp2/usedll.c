#include <stdio.h>
#include <string.h>
#include "dll.h"
#include <stdlib.h>

void print_separator(const char *test_name) {
    printf("\n=== %s ===\n", test_name);
}

void test_char_list() {
    print_separator("Testing Char List Functions");
    
    dllListc cl;
    dllInitc(&cl);
    printf("✓ dllInitc: Initialized empty char list\n");
    
    dllPushc(&cl, 'A');
    dllPushc(&cl, 'B');
    dllPushc(&cl, 'C');
    printf("✓ dllPushc: Pushed C, B, A (list: C->B->A)\n");
    
    dllEnqueuec(&cl, 'X');
    dllEnqueuec(&cl, 'Y');
    dllEnqueuec(&cl, 'Z');
    printf("✓ dllEnqueuec: Enqueued X, Y, Z (list: C->B->A->X->Y->Z)\n");
    
    dllNodec *found = dllFindc(&cl, 'A');
    printf("✓ dllFindc: Finding 'A': %s\n", found ? "FOUND" : "NOT FOUND");
    
    found = dllFindc(&cl, 'Q');
    printf("✓ dllFindc: Finding 'Q' (not in list): %s\n", found ? "FOUND" : "NOT FOUND");
    
    char c = dllPopc(&cl, '?');
    printf("✓ dllPopc: Popped '%c' from front (list now: B->A->X->Y->Z)\n", c);
    
    c = dllShiftc(&cl, '?');
    printf("✓ dllShiftc: Shifted '%c' from back (list now: B->A->X->Y)\n", c);
    
    dllPopc(&cl, '?'); // B
    dllPopc(&cl, '?'); // A
    dllPopc(&cl, '?'); // X
    dllPopc(&cl, '?'); // Y
    c = dllPopc(&cl, '!');
    printf("✓ dllPopc on empty: Returned '%c' (should be '!')\n", c);
    
    c = dllShiftc(&cl, '@');
    printf("✓ dllShiftc on empty: Returned '%c' (should be '@')\n", c);
    
    dllPushc(&cl, '1');
    dllPushc(&cl, '2');
    dllPushc(&cl, '3');
    printf("✓ Rebuilt list with 3, 2, 1\n");
    
    dllClearc(&cl);
    printf("✓ dllClearc: Cleared entire list\n");
    
    c = dllPopc(&cl, '#');
    printf("✓ dllPopc after clear: Returned '%c' (should be '#')\n", c);
}

void test_string_list() {
    print_separator("Testing String List Functions");
    
    dllLists sl;
    dllInits(&sl);
    printf("✓ dllInits: Initialized empty string list\n");
    
    dllPushs(&sl, "apple");
    dllPushs(&sl, "banana");
    dllPushs(&sl, "cherry");
    printf("✓ dllPushs: Pushed cherry, banana, apple (list: cherry->banana->apple)\n");
    
    dllEnqueues(&sl, "xray");
    dllEnqueues(&sl, "yankee");
    dllEnqueues(&sl, "zulu");
    printf("✓ dllEnqueues: Enqueued xray, yankee, zulu\n");
    
    dllNodes *found = dllFinds(&sl, "banana");
    printf("✓ dllFinds: Finding 'banana': %s\n", found ? "FOUND" : "NOT FOUND");
    
    found = dllFinds(&sl, "orange");
    printf("✓ dllFinds: Finding 'orange' (not in list): %s\n", found ? "FOUND" : "NOT FOUND");
    
    char *s = dllPops(&sl, NULL);
    printf("✓ dllPops: Popped '%s' from front\n", s ? s : "NULL");
    
    s = dllShifts(&sl, NULL);
    printf("✓ dllShifts: Shifted '%s' from back\n", s ? s : "NULL");
    
    dllPops(&sl, NULL); // banana
    dllPops(&sl, NULL); // apple
    dllPops(&sl, NULL); // xray
    dllPops(&sl, NULL); // yankee
    s = dllPops(&sl, "EMPTY");
    printf("✓ dllPops on empty: Returned '%s' (should be 'EMPTY')\n", s);
    
    s = dllShifts(&sl, "ALSO_EMPTY");
    printf("✓ dllShifts on empty: Returned '%s' (should be 'ALSO_EMPTY')\n", s);
    
    dllPushs(&sl, "one");
    dllPushs(&sl, "two");
    dllPushs(&sl, "three");
    printf("✓ Rebuilt list with three, two, one\n");
    
    dllClears(&sl);
    printf("✓ dllClears: Cleared entire list\n");
    
    s = dllPops(&sl, "CLEARED");
    printf("✓ dllPops after clear: Returned '%s' (should be 'CLEARED')\n", s);
}

void test_detach_functions() {
    print_separator("Testing Detach Functions");
    
    dllListc cl;
    dllInitc(&cl);
    dllPushc(&cl, 'A');
    dllPushc(&cl, 'B');
    dllPushc(&cl, 'C');
    
    dllNodec *middle = cl.head->next; // B
    dllDetachc(middle);
    printf("✓ dllDetachc: Detached middle node (B)\n");
    printf("  Node prev pointer: %s\n", middle->prev == NULL ? "NULL" : "NOT NULL");
    printf("  Node next pointer: %s\n", middle->next == NULL ? "NULL" : "NOT NULL");
    free(middle);  // Free the detached node!
    
    dllClearc(&cl);
    
    dllLists sl;
    dllInits(&sl);
    dllPushs(&sl, "first");
    dllPushs(&sl, "second");
    dllPushs(&sl, "third");
    
    dllNodes *smiddle = sl.head->next; // second
    dllDetachs(smiddle);
    printf("✓ dllDetachs: Detached middle node (second)\n");
    printf("  Node prev pointer: %s\n", smiddle->prev == NULL ? "NULL" : "NOT NULL");
    printf("  Node next pointer: %s\n", smiddle->next == NULL ? "NULL" : "NOT NULL");
    free(smiddle);  // Free the detached node!
    
    dllClears(&sl);
}

void test_edge_cases() {
    print_separator("Testing Edge Cases");
    
    dllListc cl;
    dllInitc(&cl);
    dllPushc(&cl, 'X');
    char c = dllPopc(&cl, '?');
    printf("✓ Single element char list - pop: '%c'\n", c);
    printf("  List head: %s, List tail: %s\n", 
           cl.head == NULL ? "NULL" : "NOT NULL",
           cl.tail == NULL ? "NULL" : "NOT NULL");
    
    dllPushc(&cl, 'Y');
    c = dllShiftc(&cl, '?');
    printf("✓ Single element char list - shift: '%c'\n", c);
    printf("  List head: %s, List tail: %s\n", 
           cl.head == NULL ? "NULL" : "NOT NULL",
           cl.tail == NULL ? "NULL" : "NOT NULL");
    
    dllLists sl;
    dllInits(&sl);
    dllPushs(&sl, "solo");
    char *s = dllPops(&sl, NULL);
    printf("✓ Single element string list - pop: '%s'\n", s);
    printf("  List head: %s, List tail: %s\n", 
           sl.head == NULL ? "NULL" : "NOT NULL",
           sl.tail == NULL ? "NULL" : "NOT NULL");
    
    dllPushs(&sl, "alone");
    s = dllShifts(&sl, NULL);
    printf("✓ Single element string list - shift: '%s'\n", s);
    printf("  List head: %s, List tail: %s\n", 
           sl.head == NULL ? "NULL" : "NOT NULL",
           sl.tail == NULL ? "NULL" : "NOT NULL");
}

int main(int argc, char *argv[]) {
    printf("===========================================\n");
    printf("  COMPREHENSIVE DLL FUNCTION TEST SUITE\n");
    printf("===========================================\n");
    
    test_char_list();
    test_string_list();
    test_detach_functions();
    test_edge_cases();
    
    printf("\n===========================================\n");
    printf("  ALL TESTS COMPLETED\n");
    printf("===========================================\n");
    
    return 0;
}
