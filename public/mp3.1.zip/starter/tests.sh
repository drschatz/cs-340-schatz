#!/bin/sh

TOTAL=79
LEAK_POINTS=10

leakcheck() {
  rm -f .leaks
  valgrind --trace-children=yes --leak-check=full -q --log-file=.leaks "$@" >/dev/null 2>/dev/null
  [ -e .leaks ] && stat -c %s .leaks || echo 0
  rm -f .leaks
}

if cpp utf8lib.c | grep -Eq 'printf|puts|putc|\bf?write\b|\bsend\b|perror'
then
  echo "❌ utf8lib.c has no printing commands during testing"
  echo "SCORE: 0 / $TOTAL"
  exit 0
fi

if [ utf8lib.c -nt tester ]
then
  make clean
  make tester
fi

if [ ! -e tester ]
then
  echo "❌ code compiles"
  echo "SCORE: 0 / $TOTAL"
  exit 0
fi

res="$(./tester 2>&1)"
echo "${res%SCORE: *}"

if [ "${res%SCORE: *}" = "$res" ]
then
  echo "❌ tester crashes"
  echo "SCORE: 0 / $TOTAL"
else
  earned="$(echo "$res" | sed -n 's|.*SCORE: *\([0-9][0-9]*\) */.*|\1|p' | tail -n 1)"
  [ -z "$earned" ] && earned=0

  if [ "$(leakcheck ./tester)" -gt 1 ]
  then
    echo "❌ valgrind passes"
    leak=0
  else
    echo "✅ valgrind passes"
    leak=$LEAK_POINTS
  fi

  echo "SCORE: $((earned + leak)) / $TOTAL"
fi