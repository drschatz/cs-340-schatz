#define CATCH_CONFIG_MAIN
#include "lib/catch.hpp"
