#include "dll.h"
#include <string.h>
#include <stdlib.h>

/**
 * Removes this node from its list, does not free the memory
 * Optional helper functions
void dllDetachc(dllNodec *self){}
void dllDetachs(dllNodes *self){}
*/