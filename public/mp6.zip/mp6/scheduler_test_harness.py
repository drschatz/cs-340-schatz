#Do not edit! You also don't need to look at this file at all.

import json
import os
import subprocess
import tempfile
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class SchedulerResult:
    """One entry from summary.json. Fields can be read as result.job_id or result["job_id"]."""
    job_id: int
    cmd: str
    cpu: int
    priority: int
    status: str                       # SUCCESS | UNSCHEDULABLE
    arrival_time_s: float
    start_time_s: Optional[float]     # None for UNSCHEDULABLE
    end_time_s: Optional[float]       # None for UNSCHEDULABLE

    def __getitem__(self, key: str):
        return getattr(self, key)


def run_scheduler(
    scheduler_path: str,
    job_lines: List[str],
    cpu_capacity: int = 4,
) -> List[SchedulerResult]:
    """
    Run a scheduler binary against a set of jobs and return parsed results.

    scheduler_path : path to the scheduler binary, e.g. "./scheduler_a"
    job_lines      : one string per job, e.g.
                     "unique_ID=0 cpu=2 priority=3 arrival_time=0 workload 2"
    cpu_capacity   : total CPU cores available

    Returns one SchedulerResult per job, sorted by job_id.
    """
    scheduler_path = os.path.abspath(scheduler_path)

    with tempfile.TemporaryDirectory() as tmpdir:
        jobs_file = os.path.join(tmpdir, "jobs.txt")
        summary_file = os.path.join(tmpdir, "summary.json")

        with open(jobs_file, "w", encoding="utf-8") as f:
            for line in job_lines:
                f.write(line + "\n")

        cmd = [
            scheduler_path,
            jobs_file,
            "--cpu-capacity", str(cpu_capacity),
            "--summary", summary_file,
        ]

        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, timeout=120
            )
        except FileNotFoundError:
            raise RuntimeError(
                f"Scheduler binary not found: {scheduler_path}\n"
                f"Make sure it is compiled and the path is correct."
            )
        except subprocess.TimeoutExpired:
            raise AssertionError("Scheduler did not finish within 120 seconds.")

        assert os.path.exists(summary_file), (
            f"summary.json was not created by {scheduler_path}.\n"
            f"stderr: {proc.stderr[:500]}"
        )

        with open(summary_file, "r", encoding="utf-8") as f:
            raw = json.load(f)

        results = [
            SchedulerResult(
                job_id=e["job_id"],
                cmd=e["cmd"],
                cpu=e["cpu"],
                priority=e["priority"],
                status=e["status"],
                arrival_time_s=e["arrival_time_s"],
                start_time_s=e.get("start_time_s"),
                end_time_s=e.get("end_time_s"),
            )
            for e in raw
        ]
        return sorted(results, key=lambda r: r.job_id)


def assert_statuses(results: List[SchedulerResult], expected: List[str]) -> None:
    """Assert statuses match expected, in job_id order."""
    actual = [r.status for r in sorted(results, key=lambda r: r.job_id)]
    assert actual == expected, (
        f"Status mismatch.\n  Expected: {expected}\n  Got:      {actual}"
    )


def get_by_id(results: List[SchedulerResult], job_id: int) -> SchedulerResult:
    """Return the result with the given job_id. Raises if not found."""
    for r in results:
        if r.job_id == job_id:
            return r
    raise KeyError(f"No result with job_id={job_id}")
