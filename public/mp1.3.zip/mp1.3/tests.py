from subprocess import run
from os.path import exists
from os import unlink, stat

def valgrind(command, points, msg, msg2=None, timeout=None):
    """Runs valgrind on one command-line invocation."""
    if exists('.leaks'):
        unlink('.leaks')
    run(f'valgrind --trace-children=yes --leak-check=full -q --log-file=.leaks {command}',
        shell=True, capture_output=True, timeout=timeout)
    if exists('.leaks') and stat('.leaks').st_size > 2:
        print('❌ valgrind', msg2 if msg2 else msg)
        unlink('.leaks')
        return 0
    else:
        print('✅ valgrind', msg)
        return points

#Exact labels the program prints, in order. Each should read "<label>: success".
EXPECTED = [
    "dllInitc",
    "dllPushc",
    "dllEnqueuec",
    "dllFindc test 1",
    "dllFindc test 2",
    "dllPopc",
    "dllShiftc",
    "dllClearc",
    "Empty popc and shiftc",
    "dllInits",
    "dllPushs",
    "dllEnqueues",
    "dllFinds test 1",
    "dllFinds test 2",
    "dllPops",
    "dllShifts",
    "dllClears",
    "Empty pops and shifts",
]

score = 0
try:
    run(['make', '--silent', 'clean'])
    run(['make', '--silent', 'dll_c'])
    if not exists('dll_c'):
        print('❌ failed to build with make')
        quit()
    else:
        print('✅ built without warnings or errors')

    res = run('./dll_c', shell=True, capture_output=True, timeout=5)
    output = res.stdout.decode('utf-8')

    lines = [ln.rstrip('\n') for ln in output.splitlines() if ln.strip() != '']

    #Guard against extra or missing print statements.
    if len(lines) > len(EXPECTED):
        print(f'❌ too many print statements (remove print statements in dll.c)')
        for ln in lines[len(EXPECTED):]:
            print(f'     ➕ {ln}')
        quit()
    if len(lines) < len(EXPECTED):
        print(f'❌ too few print statements (it may have crashed, run ./dll_c to see details)')
        quit()

    for i, (label, line) in enumerate(zip(EXPECTED, lines)):
        success = f'{label}: success'
        failed = f'{label}: failed'
        if line == success:
            print(f'✅ {label}')
            score += 1
        elif line == failed:
            print(f'❌ {label}: test reported failure')
        else:
            print(f'❌ unexpected output at line {i + 1}: expected {success!r}, got {line!r}')
            quit()

    score += valgrind('./dll_c', 5, 'no memory leaks')

finally:
    print(f'\nSCORE: {score} / {len(EXPECTED) + 5}')