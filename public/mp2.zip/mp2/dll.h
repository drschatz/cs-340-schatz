#ifndef _LINKED_LIST_H_
#define _LINKED_LIST_H_

// predeclaration of four datatypes
struct dllNodec; //double linked list node for a char
struct dllNodes; //double linked list node for a char*
struct dllListc; //double linked list for a list of chars
struct dllLists; //double linked list for a list of char*s

typedef struct dllNodec {
  char data;
  struct dllNodec *next;
  struct dllNodec *prev;
} dllNodec;

typedef struct dllNodes {
  char *data;
  struct dllNodes *next;
  struct dllNodes *prev;
} dllNodes;

typedef struct dllListc {
  dllNodec *head, *tail;
} dllListc;

typedef struct dllLists {
  dllNodes *head, *tail;
} dllLists;

/**
 * Removes this node from its list, does not free the memory
 */
void dllDetachc(dllNodec *self);
void dllDetachs(dllNodes *self);

// initializng a double linked list for a list of dllNodec's
void dllInitc(dllListc *self);

// initializng a double linked list for a list of dllNodes's
void dllInits(dllLists *self);

/**
 * Destroys the list, and frees all nodes inside it (but not values stored in them)
 */
void dllClearc(dllListc *self);
void dllClears(dllLists *self);

/**
 * Find a value in the list.
 * 
 * @param value  the value to search for
 * @return a pointer to the node containing the item, or NULL if not found
 */
dllNodec *dllFindc(const dllListc *self, const char value);
dllNodes *dllFinds(const dllLists *self, const char *value);

/**
 * Remove, free, and return the value at the head of the list.
 * This is a stack pop operation and a queue remove operation.
 * 
 * @param ifEmpty  the value to return if the list is empty.
 * @return the value removed, or ifEmpty if there is not such value.
 */
char dllPopc(dllListc *self, char ifEmpty);
char *dllPops(dllLists *self, char *ifEmpty);

/**
 * Remove, free, and return the value at the tail of the list.
 * This is not used by stacks or queues, but is included for completeness.
 * 
 * @param ifEmpty  the value to return if the list is empty.
 * @return the value removed, or ifEmpty if there is not such value.
 */
char dllShiftc(dllListc *self, char ifEmpty);
char *dllShifts(dllLists *self, char *ifEmpty);

/**
 * Add a new value to the head of the list.
 * This is the stack push operation.
 * 
 * @param value  the value to add to the list.
 */
void dllPushc(dllListc *self, char value);
void dllPushs(dllLists *self, char *value);

/**
 * Add a new value to the tail of the list.
 * This is the queue insert operation.
 * 
 * @param value  the value to add to the list.
 */
void dllEnqueuec(dllListc *self, char value);
void dllEnqueues(dllLists *self, char *value);

#endif

