#!/usr/bin/env python3
"""
Usage:
    python3 grade.py                       grades newdomain.py and walkthrough.txt in this folder
    python3 grade.py DOMAIN.py WALK.txt    grades the files you name
    python3 grade.py --json results.json   also writes the results to a file

The grader starts your domain on a spare port, pretends to be the hub and the
web UI, and checks that your domain follows the rules on the project page.
It does not need the practice hub to be running.
"""
import argparse, asyncio, json, os, random, re, socket, subprocess, sys, tempfile

from aiohttp import web


# ---------------------------------------------------------------------------
POINTS = {
    'register':    4,
    'items':       4,
    'secret':      8,
    'presence':   10,
    'basics':      4,
    'carried':     8,
    'dropped':    10,
    'same_name':   4,
    'isolation':   4,
    'restart':    10,
    'walk_win':   11,
    'exit':        3,
    'walk_names':  5,
    'walk_gates':  9,
    'walk_second': 6,
}


HIDDEN = {'open': 0, 'locked': 1}
HIDDEN_NAME = {0: 'open', 1: 'locked'}


class Fail(Exception):
    """Raised by a test when the domain does something wrong; the message is shown to the student"""

def need(condition, message):
    if not condition: raise Fail(message)


# ---------------------------------------------------------------------------
HUB_VERBS = ['journey', 'region', 'inventory', 'score', 'drop']
DOMAIN_VERBS = ['go', 'north', 'south', 'east', 'west', 'look', 'take', 'use', 'open', 'close', 'tell', 'read']
DELETE_ME = set("""a an the about above across after against among around at before behind below beside between by
    during for from in inside into near of off on out over through to toward under with aboard along amid as beneath
    beyond but concerning considering despite except following like minus next onto opposite outside past per plus
    regarding round save since than till underneath unlike until upon versus via within without""".split())
CANONIZE = [(['take', 'inventory'], ['inventory'])] + [([d], ['go', d]) for d in ('north', 'south', 'east', 'west')]
OPPOSITE = {'north': 'south', 'south': 'north', 'east': 'west', 'west': 'east'}

def clean_text(s):
    s = re.sub(r'  +', ' ', re.sub(r'[^- A-Za-z0-9]', '', s.strip().lower()))
    if s == '': return []
    w = s.split(' ')
    opts = [v for v in HUB_VERBS if v.startswith(w[0]) and v != 'score'] + [v for v in DOMAIN_VERBS if v.startswith(w[0])]
    if len(opts) == 1: w[0] = opts[0]
    w = [e for e in w if e not in DELETE_ME]
    for old, new in CANONIZE:
        if w[:len(old)] == old: w[:len(old)] = new
    return w


# ---------------------------------------------------------------------------
def made_up_word(length=3):
    while True:
        word = ''.join(random.choice('bdfgklmnprstvz') + random.choice('aeiou') for _ in range(length)) + random.choice('bdgklmnprst')
        if word not in DELETE_ME and not any(v.startswith(word) for v in HUB_VERBS + DOMAIN_VERBS):
            return word

def marker():
    return ''.join(random.choice('BCDFGHJKLMNPQRSTVWXZ') for _ in range(9))

def random_hosted():
    """Items for the domain to host, with made-up names: one open, one locked, and one extra"""
    names = set()
    while len(names) < 3: names.add(made_up_word())
    depths = [0, 1, random.randrange(2)]
    return [{'name': n, 'description': f'A {n} left here by another domain. It is stamped {marker()}.', 'verb': {}, 'depth': d}
            for n, d in zip(sorted(names), depths)]

def practice_hosted(rename=None):
    """The practice hub's hosted items; rename maps the usual names to replacements"""
    rename = rename or {}
    depths = [0, 1, random.randrange(2)]
    return [{'name': rename.get(n, n), 'description': f"It's not clear what this is, but someone reported it as hidden {HIDDEN_NAME[d]}.", 'verb': {}, 'depth': d, 'role': n}
            for n, d in zip(['doodad', 'whatsit', 'trinket'], depths)]

def carried_item(name=None):
    """An item from some other domain that a user is already carrying when they arrive"""
    return {'name': name or made_up_word(), 'description': f'An odd souvenir from far away, engraved {marker()}.',
            'verb': {made_up_word(): f'It hums the note {marker()}.'}}


# ---------------------------------------------------------------------------
class Hub:
    def __init__(self, url):
        self.url = url
        self.next_uid = 0       # user ids keep counting up across tests, so that tests do not share users
        self.reset([])

    def reset(self, hosted):
        self.hosted_spec = hosted
        self.domain = None      # {'id', 'secret', 'url', 'name', 'description', 'items'} once registered
        self.templates = {}     # {item id: {'name', 'description', 'verb', 'home', 'depth'?, 'role'?}}
                                # internally 'depth' is 0 for open and 1 for locked; domains see the field 'hidden'
        self.hosted = []        # ids of the items the domain hosts
        self.users = {}         # {user id: {'inv', 'had', 'score', 'stage', 'events'}}
        self.problems = []      # things the domain got wrong when calling the hub
        self.transfers = 0      # how many /transfer requests the domain has sent

    # --- endpoints the domain calls ---

    def routes(self):
        routes = web.RouteTableDef()
        hub = self

        @routes.post('/register')
        async def register(req):
            try: data = await req.json()
            except Exception: return web.json_response(status=400, data={'error': 'JSON data required'})
            if not isinstance(data, dict): return web.json_response(status=400, data={'error': 'JSON object required'})
            for key, kind, label in (('name', str, 'Name string'), ('description', str, 'Description string'), ('url', str, 'Server url')):
                if not isinstance(data.get(key), kind):
                    return web.json_response(status=400, data={'error': label + ' required'})
            if not isinstance(data.get('items'), list) or any(not isinstance(i, dict) for i in data['items']):
                return web.json_response(status=400, data={'error': 'List of item templates required'})
            if hub.domain is not None:
                return web.json_response(status=409, data={'error': 'Cannot register same domain more than once'})
            did = random.randrange(100, 1000)
            hub.domain = {'id': did, 'secret': marker() + marker(), 'url': data['url'], 'name': data['name'],
                          'description': data['description'], 'items': data['items']}
            tid = random.randrange(100, 800)
            ids = []
            for item in data['items']:
                tid += random.randrange(1, 4)
                t = {'name': item.get('name', 'thing'), 'description': item.get('description', ''), 'verb': item.get('verb', {}), 'home': did}
                if item.get('hidden') in HIDDEN: t['depth'] = HIDDEN[item['hidden']]
                hub.templates[tid] = t
                ids.append(tid)
            for item in hub.hosted_spec:
                tid += random.randrange(1, 4)
                hub.templates[tid] = dict(item, home=-1)
                hub.hosted.append(tid)
            return web.json_response({'id': did, 'items': ids, 'secret': hub.domain['secret']})

        async def checked(req, endpoint):
            """Returns (data, user record) for a valid request from the domain, or an error response"""
            try: data = await req.json()
            except Exception: return web.json_response(status=400, data={'error': 'JSON data required'})
            if not isinstance(data, dict): return web.json_response(status=400, data={'error': 'JSON object required'})
            for key in ('domain', 'secret'):
                if key not in data:
                    hub.problems.append(f'{endpoint} request without a "{key}" field')
                    return web.json_response(status=400, data={'error': 'Request must contain ' + key})
            if hub.domain is None or data['domain'] != hub.domain['id'] or data['secret'] != hub.domain['secret']:
                hub.problems.append(f'{endpoint} request with the wrong domain id or secret')
                return web.json_response(status=403, data={'error': 'Invalid domain or secret'})
            if data.get('user') not in hub.users or isinstance(data.get('user'), bool):
                hub.problems.append(f'{endpoint} request for a user the hub does not know: {data.get("user")!r}')
                return web.json_response(status=400, data={'error': 'Valid user ID required'})
            return data, hub.users[data['user']]

        @routes.post('/transfer')
        async def transfer(req):
            got = await checked(req, '/transfer')
            if not isinstance(got, tuple): return got
            data, user = got
            hub.transfers += 1
            tid = data.get('item')
            if isinstance(tid, bool) or tid not in hub.templates:
                hub.problems.append(f'/transfer of an item id the hub does not know: {tid!r}')
                return web.json_response(status=400, data={'error': 'Valid item ID required'})
            if 'to' not in data or data['to'] is None:
                hub.problems.append('/transfer request without a "to" field')
                return web.json_response(status=400, data={'error': 'Missing "to" field'})
            old, new = user['inv'].get(tid), data['to']
            mine = hub.templates[tid]['home'] == hub.domain['id']
            if old == new or old == ('at', new):
                return web.json_response(status=409, data={'error': 'Cannot move item to where it already is'})
            if old is None and not mine and tid not in hub.hosted:
                return web.json_response(status=403, data={'error': "Cannot generate items that don't belong to you"})
            if old is None and mine and 'depth' in hub.templates[tid]:
                kind = HIDDEN_NAME[hub.templates[tid]['depth']]
                hub.problems.append(f'your domain placed its own {kind} item {hub.templates[tid]["name"]!r} itself; '
                                    'the hub hides your open and locked items in other domains, so never /transfer them yourself')
            if old == 'inventory' and not mine:
                return web.json_response(status=403, data={'error': "Cannot move or remove items that don't belong to you"})
            if new == 'inventory':
                user['inv'][tid] = 'inventory'
                user['had'].add(tid)
                user['events'].append(('take', tid))
            else:
                user['inv'][tid] = ('at', new)
            return web.json_response({'ok': 'Item transferred'})

        @routes.post('/query')
        async def query(req):
            got = await checked(req, '/query')
            if not isinstance(got, tuple): return got
            data, user = got
            if ('location' in data) == ('hidden' in data):
                hub.problems.append('/query request must have exactly one of "location" and "hidden"')
                return web.json_response(status=400, data={'error': 'Must provide exactly one of location and hidden'})
            if 'hidden' in data and data['hidden'] not in HIDDEN:
                hub.problems.append(f'/query request with hidden {data["hidden"]!r}; it must be "open" or "locked"')
                return web.json_response(status=400, data={'error': 'hidden must be "open" or "locked"'})
            if 'location' in data:
                where = data['location']
                if where is None: return web.json_response(status=400, data={'error': 'Location required'})
                want = 'inventory' if where == 'inventory' else ('at', where)
                return web.json_response([tid for tid, loc in user['inv'].items() if loc == want])
            return web.json_response([tid for tid in hub.hosted if tid not in user['inv'] and hub.templates[tid].get('depth') == HIDDEN[data['hidden']]])

        @routes.post('/score')
        async def score(req):
            got = await checked(req, '/score')
            if not isinstance(got, tuple): return got
            data, user = got
            try: value = float(data['score'])
            except Exception:
                hub.problems.append('/score request without a numeric "score"')
                return web.json_response(status=400, data={'error': 'Numeric score required'})
            if value < 0 or value > 1.005:
                hub.problems.append(f'/score of {value}, which is not between 0 and 1')
                return web.json_response(status=400, data={'error': 'Invalid score; should be between 0 and 1'})
            if value < user['score']:
                return web.json_response(status=409, data={'error': 'Reducing scores is not supported'})
            user['score'] = value
            user['events'].append(('score', value))
            return web.json_response({'ok': 'Score changed'})

        return routes

    def new_user(self):
        uid = self.next_uid
        self.next_uid += 1
        self.users[uid] = {'inv': {}, 'had': set(), 'score': 0, 'stage': 0, 'events': []}
        return uid

    def give(self, uid, item):
        """Puts an item from some other domain straight into a user's inventory"""
        tid = max(self.templates, default=1000) + random.randrange(1, 4)
        self.templates[tid] = dict(item, home=-2)
        self.users[uid]['inv'][tid] = 'inventory'
        self.users[uid]['had'].add(tid)
        return tid

    def carrying(self, uid):
        return [tid for tid, loc in self.users[uid]['inv'].items() if loc == 'inventory']

    def arrival(self, uid, src):
        """The body of an /arrive request"""
        did = self.domain['id']
        owned, carried, dropped, prize = [], [], [], []
        for tid, loc in self.users[uid]['inv'].items():
            t = self.templates[tid]
            brief = {k: t[k] for k in ('name', 'description', 'verb')}
            brief['id'] = tid
            if loc == 'inventory': (owned if t['home'] == did else carried).append(brief)
            else:
                brief['location'] = loc[1]
                dropped.append(brief)
        for tid in self.hosted:
            if tid not in self.users[uid]['inv']:
                t = self.templates[tid]
                prize.append({'id': tid, 'name': t['name'], 'description': t['description'], 'verb': t['verb'], 'hidden': HIDDEN_NAME[t['depth']]})
        return {'secret': self.domain['secret'], 'user': uid, 'from': src,
                'owned': owned, 'carried': carried, 'dropped': dropped, 'prize': prize}

    def simulated_trip(self, uid, grant_up_to):
        """What the practice hub does on a journey: the user finds the domain's own items of
        each kind (open, then locked) once they carry the hosted item that would get them past that barrier."""
        user = self.users[uid]
        did = self.domain['id']
        key_for = {}  # 0 (open) or 1 (locked) -> the hosted item a user must carry to get past that stage
        for tid in self.hosted:
            if self.templates[tid].get('role') != 'trinket':
                key_for.setdefault(self.templates[tid]['depth'], tid)
        found = []
        for stage in range(2):
            if user['stage'] != stage: continue
            if stage <= grant_up_to:
                for tid, t in self.templates.items():
                    if t['home'] == did and t.get('depth') == stage and tid not in user['had']:
                        user['inv'][tid] = 'inventory'
                        user['had'].add(tid)
                        found.append(t['name'])
            if stage in key_for and user['inv'].get(key_for[stage]) == 'inventory':
                user['stage'] = stage + 1
        return found


# ---------------------------------------------------------------------------
class World:
    def __init__(self, hub, domain_post):
        self.hub = hub
        self.post = domain_post   # async (path, json=None, text=None) -> (status, content type, body text)
        self.grant_up_to = 2
        self.saw_journey = False
        self.dropped_called_transfer = False

    async def register(self, hosted=None):
        self.hub.reset(random_hosted() if hosted is None else hosted)
        status, ctype, body = await self.post('/newhub', text=self.hub.url)
        need(self.hub.domain is not None, f'/newhub did not register with the hub (your /newhub returned status {status})')
        need(status == 200, f'/newhub returned status {status}; expected 200 after registering with the hub')
        return status, ctype, body

    async def send_arrive(self, uid, src='login', secret=None):
        body = self.hub.arrival(uid, src)
        if secret is not None: body['secret'] = secret
        return (await self.post('/arrive', json=body))[0]

    async def send_depart(self, uid, secret=None):
        return (await self.post('/depart', json={'secret': secret or self.hub.domain['secret'], 'user': uid}))[0]

    async def login(self, carry=()):
        """A new user arrives, already carrying the given items. Returns (user id, ids of those items)."""
        uid = self.hub.new_user()
        tids = [self.hub.give(uid, item) for item in carry]
        status = await self.send_arrive(uid)
        need(status == 200, f'/arrive returned status {status} for a new user; expected 200')
        return uid, tids

    async def say(self, uid, text, depth=0):
        """Types a line as a user, the way the web UI would. Returns (status, content type, body text)."""
        words = clean_text(text)
        if not words: return 200, 'text/plain', ''
        if words[0] == 'journey': return await self.journey(uid, words[1:])
        if words[0] == 'drop': return await self.drop(uid, words[1:])
        if words[0] == 'inventory':
            return 200, 'text/plain', 'You are carrying: ' + ', '.join(self.hub.templates[t]['name'] for t in self.hub.carrying(uid))
        if words[0] in ('score', 'region'): return 200, 'text/plain', 'Nothing to report.'
        status, ctype, body = await self.post('/command', json={'user': uid, 'command': words})
        if status == 200 and body.startswith('$journey '):
            self.saw_journey = True
        if status == 200 and body.startswith('$journey ') and depth < 3:
            return await self.say(uid, body[1:], depth + 1)
        return status, ctype, body

    async def journey(self, uid, rest):
        if len(rest) != 1 or rest[0] not in OPPOSITE:
            return 403, 'text/plain', 'I only know how to journey in cardinal directions'
        status = await self.send_depart(uid)
        need(status == 200, f'/depart returned status {status}; expected 200')
        self.hub.users[uid]['events'].append(('journey',))
        found = self.hub.simulated_trip(uid, self.grant_up_to)
        status = await self.send_arrive(uid, OPPOSITE[rest[0]])
        need(status == 200, f'/arrive returned status {status} when a user came back from a journey; expected 200')
        return 200, 'text/plain', 'You travel in other domains for a time.' + ''.join(' You find a ' + n + '.' for n in found)

    async def drop(self, uid, rest):
        word = ' '.join(rest)
        gear = self.hub.carrying(uid)
        matches = [t for t in gear if str(t) == word] or [t for t in gear if self.hub.templates[t]['name'] == word]
        if len(matches) != 1: return 200, 'text/plain', 'You have no single ' + word + ' to drop'
        tid = matches[0]
        t = self.hub.templates[tid]
        before = self.hub.transfers
        status, ctype, body = await self.post('/dropped', json={'secret': self.hub.domain['secret'], 'user': uid,
            'item': {'id': tid, 'name': t['name'], 'description': t['description'], 'verb': t['verb']}})
        need(status == 200, f'/dropped returned status {status}; expected 200 with the location name as plain text')
        spot = location_from_dropped(body)
        need(spot is not None, f'/dropped must respond with just the location name as plain text, such as foyer; got {body[:60]!r}')
        need(spot != 'inventory', '/dropped must name a location in your domain, not "inventory"')
        if self.hub.transfers != before: self.dropped_called_transfer = True
        self.hub.users[uid]['inv'][tid] = ('at', spot)
        return 200, 'text/plain', t['name'] + ' dropped.'

    async def look(self, uid, what='look'):
        status, ctype, body = await self.say(uid, what)
        need(status == 200, f'"{what}" returned status {status}; expected 200')
        return body


def location_from_dropped(text):
    """Reads the location name a domain's /dropped replied with.
    The reply should be plain text such as foyer. A JSON string such as "foyer" is also accepted.
    Returns None if the reply is empty, or is a JSON object, list, true, false, or null."""
    import json
    text = text.strip()
    try: value = json.loads(text)
    except ValueError: return text or None
    if isinstance(value, str): return value or None
    if isinstance(value, (int, float)) and not isinstance(value, bool): return text
    return None

def same_text(a, b):
    """Compares two responses, ignoring item ids"""
    return re.sub(r'\d+', '', a).strip() == re.sub(r'\d+', '', b).strip()

def show(text, limit=70):
    text = ' '.join(text.split())
    return repr(text if len(text) <= limit else text[:limit] + '...')


# ---------------------------------------------------------------------------
async def test_register(w, walk):
    status, ctype, body = await w.register()
    try: reply = json.loads(body)
    except Exception: raise Fail(f'/newhub must respond with JSON; got {show(body)}')
    need(isinstance(reply, dict) and isinstance(reply.get('ok'), str), '/newhub must respond with a JSON object like {"ok": "..."} on success')
    d = w.hub.domain
    need(d['url'].startswith('http://'), f'the "url" you register should be your whoami value; got {d["url"]!r}')
    need(d['name'].strip() and 'FIXME' not in d['name'].upper().replace(' ', ''), 'give your domain a name of its own')
    need(d['description'].strip() and 'FIXME' not in d['description'].upper().replace(' ', ''), 'give your domain a description of its own')

async def test_items(w, walk):
    await w.register()
    items = w.hub.domain['items']
    need(len(items) >= 4, f'your domain registers {len(items)} items; it needs at least 4')
    for item in items:
        name = item.get('name')
        need(isinstance(name, str) and re.fullmatch(r'[a-z0-9-]+', name) and not name.isdigit(),
             f'item name {name!r} must be a single word of lower-case letters, digits, and hyphens, and not just digits')
        need(name not in DELETE_ME, f'the web UI removes the word {name!r} from commands, so it cannot be an item name')
        need(isinstance(item.get('description'), str) and item['description'].strip(), f'item {name!r} needs a description')
        need(isinstance(item.get('verb', {}), dict), f'the "verb" field of item {name!r} must be a map from verbs to responses')
    for old in ('depth', 'outside_depth'):
        need(not any(old in item for item in items), f'an item has a field named "{old}"; the field is called "hidden"')
    kinds = [item.get('hidden', 'home') for item in items]
    for item, kind in zip(items, kinds):
        need(kind in ('home', 'open', 'locked'),
             f'item {item.get("name")!r} has "hidden": {json.dumps(kind)}. Use "open" or "locked", or leave the field out for an item that stays in your domain')
    need(kinds.count('home') > 0,
         'all of your items have a "hidden" field, so all of them will be hidden in other domains. '
         'Leave out the "hidden" field for items that stay in your domain')
    need(kinds.count('home') >= 2, f'your domain has {kinds.count("home")} item that stays in your domain; it needs at least 2 with no "hidden" field')
    need(kinds.count('open') >= 1, 'your domain needs at least 1 item with "hidden": "open" for other domains to host')
    need(kinds.count('locked') >= 1, 'your domain needs at least 1 item with "hidden": "locked" for other domains to host')
    need(kinds.count('open') <= 2, f'your domain has {kinds.count("open")} items with "hidden": "open"; the most allowed is 2')
    need(kinds.count('locked') <= 2, f'your domain has {kinds.count("locked")} items with "hidden": "locked"; the most allowed is 2')

async def test_secret(w, walk):
    await w.register()
    uid, _ = await w.login()
    await w.look(uid)
    status = await w.send_depart(uid, secret='not-the-secret')
    need(status == 403, f'/depart with a wrong secret returned status {status}; expected 403')
    status, _, _ = await w.say(uid, 'look')
    need(status == 200, 'a /depart with a wrong secret must be ignored, but it made the user leave')
    stranger = w.hub.new_user()
    status = await w.send_arrive(stranger, secret='not-the-secret')
    need(status == 403, f'/arrive with a wrong secret returned status {status}; expected 403')
    status, _, _ = await w.say(stranger, 'look')
    need(status == 409, 'an /arrive with a wrong secret must be ignored, but it let the user in')
    status, _, _ = await w.post('/dropped', json={'secret': 'not-the-secret', 'user': uid, 'item': dict(carried_item(), id=5)})
    need(status == 403, f'/dropped with a wrong secret returned status {status}; expected 403')

async def test_presence(w, walk):
    await w.register()
    status, _, _ = await w.post('/command', json={'user': w.hub.next_uid, 'command': ['look']})
    need(status == 409, f'a command from a user who has never arrived returned status {status}; expected 409')
    a, _ = await w.login()
    b, _ = await w.login()
    await w.look(a)
    status = await w.send_depart(a)
    need(status == 200, f'/depart returned status {status}; expected 200')
    for line in ('look', 'go north', 'take nothing'):
        status, _, _ = await w.say(a, line)
        need(status == 409, f'"{line}" from a user who has departed returned status {status}; expected 409')
    status, _, _ = await w.say(b, 'look')
    need(status == 200, f'one user departing made "look" return status {status} for a different user')
    status = await w.send_arrive(a, 'direct')
    need(status == 200, f'/arrive returned status {status} for a returning user; expected 200')
    status, _, _ = await w.say(a, 'look')
    need(status == 200, f'"look" returned status {status} after the user arrived again; expected 200')

async def test_basics(w, walk):
    await w.register()
    uid, _ = await w.login()
    status, ctype, body = await w.say(uid, 'look')
    need(status == 200, f'"look" returned status {status}; expected 200')
    need(body.strip(), '"look" returned an empty response')
    need('json' not in ctype, '/command must respond with plain text, not JSON')
    for line in (made_up_word() + ' ' + made_up_word(), 'take ' + made_up_word(), 'look ' + made_up_word(), 'take 999999',
                 'go', 'look look look look', 'use'):
        status, ctype, body = await w.say(uid, line)
        need(status == 200, f'the unexpected command "{line}" returned status {status}; say you do not understand, with status 200')
        need(body.strip(), f'the unexpected command "{line}" got an empty response')

async def test_carried(w, walk):
    await w.register()
    item = carried_item()
    verb, reply = next(iter(item['verb'].items()))
    mark = item['description'].split()[-1]
    uid, (tid,) = await w.login(carry=[item])
    body = await w.look(uid, f'look {item["name"]}')
    need(mark in body, f'"look ITEM" for an item the user carries from another domain must show its description; got {show(body)}')
    body = await w.look(uid, f'look {tid}')
    need(mark in body, f'"look ID" must work like "look NAME"; got {show(body)}')
    body = await w.look(uid, f'{verb} {item["name"]}')
    need(reply in body, f'"VERB ITEM" must show the response from the item\'s verb map, for items from other domains too; got {show(body)}')
    body = await w.look(uid, f'{verb} {tid}')
    need(reply in body, f'"VERB ID" must work like "VERB NAME"; got {show(body)}')

async def test_dropped(w, walk):
    await w.register()
    item = carried_item()
    name = item['name']
    uid, (tid,) = await w.login(carry=[item])
    before = await w.look(uid)
    need(name not in before, 'an item the user is carrying should not be listed by "look"')
    await w.say(uid, f'drop {name}')
    need(not w.dropped_called_transfer, '/dropped called /transfer; it should only answer with the location, and the hub moves the item itself')
    body = await w.look(uid)
    need(name in body, f'after "drop", "look" must list the dropped item by name; got {show(body, 200)}')
    need(str(tid) in body, 'when "look" lists an item it must also show the item\'s id')
    mark = item['description'].split()[-1]
    body = await w.look(uid, f'look {name}')
    need(mark in body, f'"look ITEM" must also work for an item in the user\'s location; got {show(body)}')
    status, _, body = await w.say(uid, f'take {tid}')
    need(status == 200, f'"take ID" returned status {status}; expected 200')
    need(w.hub.users[uid]['inv'].get(tid) == 'inventory',
         f'"take ID" must move the item to "inventory" with the hub\'s /transfer; the response was {show(body)}')
    body = await w.look(uid)
    need(name not in body, 'after "take", "look" must no longer list the item')
    await w.say(uid, f'drop {tid}')
    await w.say(uid, f'take {name}')
    need(w.hub.users[uid]['inv'].get(tid) == 'inventory', '"take NAME" must work for an item that was dropped here')
    await w.say(uid, f'drop {name}')
    w.hub.users[uid]['inv'][tid] = ('at', 'somewhere-else-' + marker().lower())
    body = await w.look(uid)
    need(name not in body, 'after the hub moved an item away, "look" still listed it; ask the hub with /query instead of keeping your own copy of where items are')

async def test_same_name(w, walk):
    await w.register()
    one, two = carried_item(), carried_item()
    two['name'] = one['name']
    uid, (tid1, tid2) = await w.login(carry=[one, two])
    mark1, mark2 = one['description'].split()[-1], two['description'].split()[-1]
    body = await w.look(uid, f'look {tid1}')
    need(mark1 in body and mark2 not in body, 'with two carried items of the same name, "look ID" must describe the one with that id')
    body = await w.look(uid, f'look {tid2}')
    need(mark2 in body and mark1 not in body, 'with two carried items of the same name, "look ID" must describe the one with that id')
    await w.look(uid, f'look {one["name"]}')

async def test_isolation(w, walk):
    await w.register()
    item = carried_item()
    a, _ = await w.login(carry=[item])
    b, _ = await w.login()
    fresh = await w.look(b)
    await w.say(a, f'drop {item["name"]}')
    mine = await w.look(a)
    need(item['name'] in mine, 'after "drop", "look" must list the dropped item')
    theirs = await w.look(b)
    need(item['name'] not in theirs, 'an item one user dropped showed up for a different user')
    need(same_text(fresh, theirs), 'what one user did changed what "look" shows a different user')
    for direction in ('north', 'east', 'south', 'west'):
        await w.say(a, 'go ' + direction)
        need(same_text(fresh, await w.look(b)), 'one user moving around changed what "look" shows a different user')

async def test_restart(w, walk):
    hosted = random_hosted()
    await w.register(hosted)
    item = carried_item()
    uid, _ = await w.login(carry=[item])
    fresh = await w.look(uid)
    await w.say(uid, f'drop {item["name"]}')
    await w.say(uid, 'go north'); await w.say(uid, 'go east'); await w.say(uid, 'go south'); await w.say(uid, 'go west')
    await w.register([dict(h) for h in hosted])
    w.hub.next_uid = uid    # the real hub starts user ids over after a reset, so reuse the same id
    uid, _ = await w.login()
    again = await w.look(uid)
    need(item['name'] not in again, 'after /newhub is called again, items dropped in the old game must be gone')
    need(same_text(fresh, again), 'after /newhub is called again, a new user must start in a fresh copy of the world')


# ---------------------------------------------------------------------------
ROLES = ('doodad', 'whatsit')

async def play(w, uid, lines, rename=None):
    """Types every line of the walkthrough. Returns the first line that did not get status 200, if any."""
    bad = None
    for line in lines:
        if rename:
            line = re.sub(r'\b(' + '|'.join(rename) + r')\b', lambda m: rename[m.group(1)], line)
        status, _, body = await w.say(uid, line)
        if status != 200 and bad is None: bad = (line, status)
    return bad

def took(w, uid):
    """Which of the doodad and whatsit the user has picked up"""
    return {w.hub.templates[t].get('role') for t in w.hub.users[uid]['had']} & set(ROLES)

def check_win(w, uid, bad, who='the walkthrough'):
    need(bad is None, f'{who} got status {bad[1] if bad else ""} from the line "{bad[0] if bad else ""}"; every line should get status 200')
    missing = [r for r in ROLES if r not in took(w, uid)]
    need(not missing, f'{who} never took the hosted ' + ' or the '.join(missing))
    need(w.hub.users[uid]['score'] >= 1.0, f'{who} finished without your domain sending the hub a /score of 1.0')

def need_walk(walk):
    need(walk is not None, 'no walkthrough file was found')
    need(walk, 'the walkthrough file has no commands in it')

async def test_walk_win(w, walk):
    need_walk(walk)
    await w.register(practice_hosted())
    uid, _ = await w.login()
    bad = await play(w, uid, walk)
    check_win(w, uid, bad)
    events = w.hub.users[uid]['events']
    doodad = next(t for t in w.hub.hosted if w.hub.templates[t]['role'] == 'doodad')
    first_trip = events.index(('journey',)) if ('journey',) in events else len(events)
    need(('take', doodad) in events[:first_trip], 'the walkthrough must take the doodad before its first journey line')
    need(not w.hub.problems, 'problem with your requests to the hub: ' + '; '.join(sorted(set(w.hub.problems))[:3]))

async def test_walk_names(w, walk):
    need_walk(walk)
    rename = {}
    while len(set(rename.values())) < len(ROLES): rename = {r: made_up_word() for r in ROLES}
    await w.register(practice_hosted(rename))
    uid, _ = await w.login()
    bad = await play(w, uid, walk, rename)
    check_win(w, uid, bad, 'the walkthrough, with the hosted items given different names,')

async def test_walk_gates(w, walk):
    need_walk(walk)
    await w.register(practice_hosted())
    uid, _ = await w.login()
    check_win(w, uid, await play(w, uid, walk), 'the unmodified walkthrough')
    # a user who never finds any of this domain's items in other domains
    await w.register(practice_hosted())
    w.grant_up_to = -1
    uid, _ = await w.login()
    await play(w, uid, walk)
    need('whatsit' not in took(w, uid), 'a user took the hosted locked item without having any of your open items')
    # the same user, but carrying items from another domain with the same names as your hidden items
    await w.register(practice_hosted())
    w.grant_up_to = -1
    impostors = [dict(name=i['name'], description=i.get('description', ''), verb=i.get('verb', {}))
                 for i in w.hub.domain['items'] if i.get('hidden') in HIDDEN]
    uid, _ = await w.login(carry=impostors)
    await play(w, uid, walk)
    need('whatsit' not in took(w, uid),
         'a user got past the barrier to your hosted locked items using another domain\'s item with the same name as yours; '
         'check for your own item\'s id, not its name')
    # a user who finds your open items but none of your locked items
    await w.register(practice_hosted())
    w.grant_up_to = 0
    uid, _ = await w.login()
    await play(w, uid, walk)
    need('whatsit' in took(w, uid),
         'a user with your open items, but none of your locked items, could not reach the hosted locked item; '
         'the barrier in front of hosted locked items must open with one of your open items, never a locked one')

async def test_walk_second(w, walk):
    need_walk(walk)
    await w.register(practice_hosted())
    b, _ = await w.login()
    fresh = await w.look(b)
    a, _ = await w.login()
    check_win(w, a, await play(w, a, walk), 'the first of two users playing the walkthrough')
    later = await w.look(b)
    need(same_text(fresh, later), 'one user playing through the domain changed what "look" shows a different user')
    check_win(w, b, await play(w, b, walk), 'a second user playing the walkthrough after the first')
    need(w.hub.users[a]['score'] >= 1.0 and w.hub.users[b]['score'] >= 1.0, 'both users should have a score of 1.0')


async def test_exit(w, walk):
    await w.register(practice_hosted())
    # explore with go north, south, east, and west from where a new user starts
    async def walk_to(path):
        """A new user follows the path; returns their user id and what "look" shows at the end"""
        uid, _ = await w.login()
        for step in path:
            await w.post('/command', json={'user': uid, 'command': ['go', step]})
        status, _, here = await w.post('/command', json={'user': uid, 'command': ['look']})
        return uid, (here if status == 200 else None)
    paths, seen = [[]], set()
    while paths and len(seen) < 25:
        path = paths.pop(0)
        uid, here = await walk_to(path)
        if here is None or re.sub(r'\d+', '', here) in seen: continue
        seen.add(re.sub(r'\d+', '', here))
        for direction in ('north', 'south', 'east', 'west'):
            uid, _ = await walk_to(path)
            status, _, body = await w.post('/command', json={'user': uid, 'command': ['go', direction]})
            if status == 200 and body.startswith('$journey '): return
            status, _, now = await w.post('/command', json={'user': uid, 'command': ['look']})
            if status == 200 and not same_text(now, here):
                paths.append(path + [direction])
    # an exit may be behind a puzzle, so also look while playing the walkthrough
    if walk:
        await w.register(practice_hosted())
        uid, _ = await w.login()
        await play(w, uid, walk)
        if w.saw_journey: return
    raise Fail('no location sends the user onward with a "$journey" response; at least one "go" direction should lead out of your domain')


TESTS = [
    ('register',    'registers with the hub',                           test_register),
    ('items',       'defines the required items',                       test_items),
    ('restart',     'calling /newhub again starts the game over',       test_restart),
    ('secret',      'refuses requests with a wrong secret',             test_secret),
    ('presence',    'answers only users who are in the domain',         test_presence),
    ('basics',      'handles look and unexpected commands',             test_basics),
    ('carried',     'carried items respond to look and their verbs',    test_carried),
    ('dropped',     'dropped items can be seen and taken',              test_dropped),
    ('same_name',   'tells apart items with the same name',             test_same_name),
    ('isolation',   'users do not affect each other',                   test_isolation),
    ('exit',        'some location leads out of the domain',            test_exit),
    ('walk_win',    'walkthrough takes the hosted items and wins',      test_walk_win),
    ('walk_names',  'walkthrough works when hosted items are renamed',  test_walk_names),
    ('walk_gates',  'hosted items are behind the right barrier',        test_walk_gates),
    ('walk_second', 'a second user can also play the walkthrough',      test_walk_second),
]


async def run_tests(hub, domain_post, walk):
    """Runs every test. Returns a list of {'key', 'name', 'points', 'max', 'message'}."""
    results = []
    for key, name, test in TESTS:
        w = World(hub, domain_post)
        message = ''
        try:
            await test(w, walk)
            points = POINTS[key]
        except Fail as ex:
            points, message = 0, str(ex)
        except Exception as ex:
            points, message = 0, 'the grader hit an unexpected problem: ' + repr(ex)
        results.append({'key': key, 'name': name, 'points': points, 'max': POINTS[key], 'message': message})
    return results

def report(results, out=sys.stdout):
    for r in results:
        print(f"[{'PASS' if r['points'] == r['max'] else 'FAIL'}] {r['points']:>2}/{r['max']:<2}  {r['name']}", file=out)
        if r['message']: print('             ' + r['message'], file=out)
    print(f"Score: {sum(r['points'] for r in results)}/{sum(r['max'] for r in results)}", file=out)

def read_walkthrough(path):
    if not os.path.exists(path): return None
    with open(path) as f:
        return [line.strip() for line in f if line.strip() and not line.strip().startswith('#')]


# ---------------------------------------------------------------------------
def free_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]

async def wait_for_port(port, proc, seconds=10):
    for _ in range(seconds * 10):
        if proc.poll() is not None: return False
        try:
            reader, writer = await asyncio.open_connection('127.0.0.1', port)
            writer.close()
            return True
        except OSError:
            await asyncio.sleep(0.1)
    return False

async def grade(domain_path, walk_path):
    from aiohttp import ClientSession, ClientTimeout
    hub_port, domain_port = free_port(), free_port()
    hub = Hub(f'http://127.0.0.1:{hub_port}')
    app = web.Application()
    app.add_routes(hub.routes())
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, '127.0.0.1', hub_port).start()

    log = tempfile.TemporaryFile(mode='w+')
    folder, filename = os.path.split(os.path.abspath(domain_path))
    proc = subprocess.Popen([sys.executable, filename, '--host', '127.0.0.1', '-p', str(domain_port)],
                            cwd=folder, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
    saw_500 = False
    try:
        if not await wait_for_port(domain_port, proc):
            log.seek(0)
            print('Your domain did not start. Its output was:\n' + log.read()[-3000:])
            return [{'key': k, 'name': n, 'points': 0, 'max': POINTS[k], 'message': 'the domain did not start'} for k, n, _ in TESTS]
        async with ClientSession(timeout=ClientTimeout(total=5)) as client:
            async def domain_post(path, json=None, text=None):
                nonlocal saw_500
                try:
                    async with client.post(f'http://127.0.0.1:{domain_port}{path}', json=json, data=text) as resp:
                        if resp.status >= 500: saw_500 = True
                        return resp.status, resp.content_type or '', await resp.text()
                except asyncio.TimeoutError:
                    raise Fail(f'your domain took more than 5 seconds to answer {path}')
                except Exception as ex:
                    raise Fail(f'your domain could not be reached at {path}: {ex!r}')
            results = await run_tests(hub, domain_post, read_walkthrough(walk_path))
    finally:
        proc.terminate()
        try: proc.wait(timeout=5)
        except subprocess.TimeoutExpired: proc.kill()
        await runner.cleanup()
    if saw_500:
        log.seek(0)
        tail = log.read()[-3000:]
        print('Your domain crashed while handling at least one request. The end of its output was:\n' + tail + '\n')
    return results


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Autograder for the CS 340 final project')
    parser.add_argument('domain', nargs='?', default='newdomain.py')
    parser.add_argument('walkthrough', nargs='?', default='walkthrough.txt')
    parser.add_argument('--json', metavar='FILE', help='also write the results to this file as JSON')
    args = parser.parse_args()
    if not os.path.exists(args.domain):
        sys.exit('Cannot find ' + args.domain)
    results = asyncio.run(grade(args.domain, args.walkthrough))
    report(results)
    if args.json:
        with open(args.json, 'w') as f:
            json.dump({'score': sum(r['points'] for r in results), 'max': sum(r['max'] for r in results), 'tests': results}, f, indent=1)
