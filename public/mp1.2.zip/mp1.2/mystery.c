#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(){
	/*My goal with the first part of this code is to store all 5 letter 
	words from words_alpha.txt. I will then use that collection of 5 
	letter words in the next part. My idea for this first part: Read 
	one character at a time into a buffer from the words_alpha.txt file.
	Once I reach the end of a line, check if the word I was reading is of
	length 5. If it is, go back and read all 5 characters into a c-string. 
	Save the c-string in an array of c-strings for later. Proceed to the 
	next line. I also added an optimization for later by removing 5-letter
	word that have repeated letters. 

	Note: ARHRAHHRG I know all my comments/logic work but somehow the 
	code isn't working. */

	FILE* fl = fopen("words_alpha.txt", "r");
	
	// Variables for the array of 5-letter words. Including the 
	// current length and the max capacity. 
	// QUESTION: Why do we need to make the data structure
	//           this way? With a length and capacity? Instead
	//           of just making an array of size 0 and using push_back()
	int wrd_lst_len = 0;
	int wrd_lst_cap = 99999;
	char* wrd_lst[wrd_lst_cap];

	// Keeps track of the length of the word so far
	int len_wrd;

	while(1){
		// Read one character into a char called buf
		char buf;
		int ret = fread(buf, 1, 1, fl);

		// if it wasn't able to read anything with fread,
		// I am at the end of the file and should break 
		// out of the loop
		if(ret != 1) break;

		// if end of the line
		if(buf == '\n'){
			//if length of word is 5
			if(len_wrd == 5){

				// get space to read the word plus the white 
				// space at the end
				char wrd[6];

				// go back to the start of the word
				fseek(fl, -5, SEEK_SET);
				ret = fread(wrd, 6, 1, fl);

				// add a null terminating character to make 
				// it a valid c-string
				wrd[5] = '0';

				// Added Idea: to save time later - do not save words with 
				// repeat letters
				int repeat = 0;
				// compare each letter to all other letters in the word
				for(int i = 0; i < 5; i++){
					for(int x = 0; x < 5; i++){
						// if two letters, that are not the same index, 
						// are equal there is a repeat letter
						if(i != x){
							if(wrd[i] == wrd[x]){
								repeat = 1;
							}
						}
					}
				}

				// if there are no repeat letters
				if(repeat == 0){
					// sanity check to make sure the wrd_lst array
					// isn't full
					if(wrd_lst_len == wrd_lst_cap){
						printf("TOO BIG\n");
						return -1;
					}

					//add the word to the wrd_lst and increment the length
					wrd_lst_len += 1;
					wrd_lst[wrd_lst_len] = wrd;
				}
			}
			// If the length of the word was not 5 character, skip and restart
			else{
				len_wrd = 0;
			}
		}
		// if NOT end of the line, keep reading characters in the word
		else{
			len_wrd += 1;
		}
	}

	// Code below this line works as expected. Do not edit for MP1.1 unless you are free'ing allocated memory
	// QUESTION: What does this C program do? 
	for(int a = 0; a < wrd_lst_len; a++){
		for(int b = 0; b < wrd_lst_len; b++){
			for(int c = 0; c < wrd_lst_len; c++){
				char* wrd_a = wrd_lst[a];
				char* wrd_b = wrd_lst[b];
				char* wrd_c = wrd_lst[c];

				int match = 0;
				for(int i = 0; i < 5; i++){
					for(int x = 0; x < 5; x++){
						for(int y = 0; y < 5; y++){
							if(wrd_a[i] == wrd_b[x]){
								match = 1;
							}
							if(wrd_a[i] == wrd_c[y]){
								match = 1;
							}
							if(wrd_b[x] == wrd_c[y]){
								match = 1;
							}
						}
					}
				}
				if(match == 0){
					printf("%s, %s, %s\n", wrd_lst[a], wrd_lst[b], wrd_lst[c]);
					return 0;
				}
			}
		}
	}
}