#include "pnglib.h"
// a place to define any shared functions you declare in pnglib.h
