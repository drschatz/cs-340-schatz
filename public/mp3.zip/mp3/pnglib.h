// a place to declare any shared functions you want to use in more than one program
