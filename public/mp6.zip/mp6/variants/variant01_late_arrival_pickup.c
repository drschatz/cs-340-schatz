/*
 * CORRECT VARIANT 1: Notices each arriving job one wake-up (0.1s) later than the reference does.
 *
 * This is a valid scheduler: every test must pass on it. It is
 * scheduler_correct.c with one timing change; search for "VARIANT".
 */
/*
 * scheduler_correct.c - reference fixed-priority preemptive scheduler
 *                       (simulated: no real processes, virtual clock)
 *
 * Time advances in 0.1s ticks without sleeping. A job "workload N" needs
 * N seconds of work, which counts down only on ticks where the job is
 * running. On each tick the scheduler:
 *   1. completes jobs whose work is finished (freeing their CPUs),
 *   2. moves newly arrived jobs into the queue,
 *   3. walks the queue (priority desc, arrival asc, job id asc) and starts
 *      as many jobs as possible. If a job does not fit, strictly lower
 *      priority running jobs are paused, lowest priority first, provided
 *      that frees enough CPUs. Paused jobs return to the queue and resume
 *      later. The queue is rescanned after every change.
 * Then every running job does one tick of work.
 *
 * Jobs needing more CPUs than the capacity are UNSCHEDULABLE and never
 * enter the queue. A job's start time is the first tick it ran.
 */
#include "scheduler_common.h"

enum { WAITING, QUEUED, RUNNING, DONE };

typedef struct {
    Job    job;
    int    state;
    long   arrival_tick;
    long   remaining;    /* ticks of work left */
    long   first_start;  /* tick of first dispatch, -1 if never started */
} JobState;

static Config   cfg;
static JobState js[MAX_JOBS];
static Result   results[MAX_JOBS];
static int      n_jobs = 0, n_results = 0;
static int      used_cpu = 0;

/* true if a should come before b in the queue */
static int before(const JobState *a, const JobState *b) {
    if (a->job.priority != b->job.priority) return a->job.priority > b->job.priority;
    if (a->job.arrival_s != b->job.arrival_s) return a->job.arrival_s < b->job.arrival_s;
    return a->job.job_id < b->job.job_id;
}

static Result *new_result(const Job *j, const char *status) {
    Result *r = &results[n_results++];
    memset(r, 0, sizeof(*r));
    r->job_id = j->job_id;
    snprintf(r->cmd, sizeof(r->cmd), "%s", j->cmd);
    r->cpu = j->cpu;
    r->priority = j->priority;
    snprintf(r->status, sizeof(r->status), "%s", status);
    r->arrival_s = j->arrival_s;
    r->start_s = -1;
    r->end_s = -1;
    return r;
}

static void start_or_resume(JobState *s, long tick) {
    if (s->first_start < 0) s->first_start = tick;
    s->state = RUNNING;
    used_cpu += s->job.cpu;
}

static void preempt(JobState *s) {
    s->state = QUEUED;
    used_cpu -= s->job.cpu;
}

/* One scheduling step. Returns 1 if something changed (caller rescans). */
static int schedule_once(long tick) {
    int q[MAX_JOBS], nq = 0;
    for (int i = 0; i < n_jobs; i++)
        if (js[i].state == QUEUED) q[nq++] = i;
    for (int a = 1; a < nq; a++) {            /* insertion sort */
        int v = q[a], b = a - 1;
        while (b >= 0 && before(&js[v], &js[q[b]])) { q[b + 1] = q[b]; b--; }
        q[b + 1] = v;
    }

    for (int k = 0; k < nq; k++) {
        JobState *s = &js[q[k]];
        int need = s->job.cpu;
        int freec = cfg.cpu_capacity - used_cpu;

        if (need <= freec) {
            start_or_resume(s, tick);
            return 1;
        }

        int avail = freec;
        for (int i = 0; i < n_jobs; i++)
            if (js[i].state == RUNNING && js[i].job.priority < s->job.priority)
                avail += js[i].job.cpu;
        if (avail < need) continue;

        /* pause lowest priority first (latest in queue order breaks ties) */
        while (cfg.cpu_capacity - used_cpu < need) {
            JobState *victim = NULL;
            for (int i = 0; i < n_jobs; i++) {
                if (js[i].state != RUNNING || js[i].job.priority >= s->job.priority) continue;
                if (!victim || before(victim, &js[i])) victim = &js[i];
            }
            preempt(victim);
        }
        start_or_resume(s, tick);
        return 1;
    }
    return 0;
}

static void complete_finished(long tick) {
    for (int i = 0; i < n_jobs; i++) {
        JobState *s = &js[i];
        if (s->state != RUNNING || s->remaining > 0) continue;
        used_cpu -= s->job.cpu;
        s->state = DONE;
        Result *r = new_result(&s->job, STATUS_SUCCESS);
        r->start_s = s->first_start * TICK_S;
        r->end_s = tick * TICK_S;
    }
}

int main(int argc, char **argv) {
    const char *jobs_file = parse_args(argc, argv, &cfg);

    static Job jobs[MAX_JOBS];
    n_jobs = parse_jobs(jobs_file, jobs, MAX_JOBS);

    for (int i = 0; i < n_jobs; i++) {
        memset(&js[i], 0, sizeof(js[i]));
        js[i].job = jobs[i];
        js[i].arrival_tick = secs_to_ticks(jobs[i].arrival_s) + 1; /* VARIANT */
        js[i].remaining = job_work_ticks(jobs[i].cmd);
        js[i].first_start = -1;
        if (jobs[i].cpu > cfg.cpu_capacity) {
            new_result(&jobs[i], STATUS_UNSCHED);   /* rule 1 */
            js[i].state = DONE;
        } else {
            js[i].state = WAITING;
        }
    }

    for (long tick = 0; ; tick++) {
        complete_finished(tick);
        for (int i = 0; i < n_jobs; i++)
            if (js[i].state == WAITING && js[i].arrival_tick <= tick)
                js[i].state = QUEUED;
        while (schedule_once(tick)) { }

        int remaining = 0;
        for (int i = 0; i < n_jobs; i++)
            if (js[i].state != DONE) remaining++;
        if (remaining == 0) break;

        /* one tick of work for everything that is running */
        for (int i = 0; i < n_jobs; i++)
            if (js[i].state == RUNNING) js[i].remaining--;
    }

    qsort(results, n_results, sizeof(Result), cmp_result_by_id);
    write_summary(&cfg, results, n_results);
    return 0;
}
